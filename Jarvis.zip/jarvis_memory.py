#!/usr/bin/env python3
"""
jarvis_memory.py — SQLite memory for jarvis's MCP agent: past turns (for context) and
a "recipe" cache (for speed).

Two tables:
- turns: what you asked + what Jarvis answered, for conversational context. Deliberately
  does NOT store the tool-call trace (every Click/App/Screenshot call) — only the final
  exchange. Replaying the full trace on every future turn would bloat the prompt and
  slow every request down, which defeats the whole point of a memory feature.
- recipes: exactly which tools (+ args) were actually called for a request that
  finished successfully, keyed by a normalized version of the request text. When a new
  request matches one closely enough, nemotron_mcp_agent.py replays those same calls
  directly against windows-mcp — no LLM call at all for that turn. This is what makes
  "abrí youtube" instant the second time, instead of paying the model's latency again
  for something it already solved.

Env:
  JARVIS_MEMORY_DB       path to the sqlite file (default: jarvis_memory.sqlite3, next
                         to this script)
  JARVIS_MEMORY_TURNS    how many past exchanges to feed back as context (default: 8)
  JARVIS_RECIPE_MATCH    similarity threshold (0-1) for reusing a cached recipe on a
                         non-exact match (default: 0.88). 1.0 = exact match only.
"""

from __future__ import annotations

import difflib
import json
import os
import re
import sqlite3
import time
import unicodedata
from pathlib import Path

DB_PATH = Path(
    os.environ.get("JARVIS_MEMORY_DB") or (Path(__file__).resolve().parent / "jarvis_memory.sqlite3")
)
DEFAULT_HISTORY_TURNS = int(os.environ.get("JARVIS_MEMORY_TURNS", "8"))
RECIPE_MATCH_THRESHOLD = float(os.environ.get("JARVIS_RECIPE_MATCH", "0.88"))


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS turns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL NOT NULL,
            user_text TEXT NOT NULL,
            assistant_text TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS recipes (
            normalized_text TEXT PRIMARY KEY,
            transcript TEXT NOT NULL,
            tool_calls_json TEXT NOT NULL,
            final_text TEXT NOT NULL,
            updated_ts REAL NOT NULL,
            hits INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    return conn


def normalize(text: str) -> str:
    """Lowercase, strip accents/punctuation, collapse whitespace — for matching, not
    for display."""
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def save_turn(user_text: str, assistant_text: str) -> None:
    user_text = (user_text or "").strip()
    assistant_text = (assistant_text or "").strip()
    if not user_text and not assistant_text:
        return
    with _connect() as conn:
        conn.execute(
            "INSERT INTO turns (ts, user_text, assistant_text) VALUES (?, ?, ?)",
            (time.time(), user_text, assistant_text),
        )


def load_recent_as_messages(limit: int | None = None) -> list[dict]:
    """Recent turns as alternating user/assistant messages, oldest first — ready to
    splice into a chat `messages` list right after the system prompt."""
    n = limit if limit is not None else DEFAULT_HISTORY_TURNS
    if n <= 0:
        return []
    with _connect() as conn:
        rows = conn.execute(
            "SELECT user_text, assistant_text FROM turns ORDER BY id DESC LIMIT ?", (n,)
        ).fetchall()
    rows.reverse()
    messages: list[dict] = []
    for user_text, assistant_text in rows:
        if user_text:
            messages.append({"role": "user", "content": user_text})
        if assistant_text:
            messages.append({"role": "assistant", "content": assistant_text})
    return messages


def save_recipe(transcript: str, tool_calls: list[dict], final_text: str) -> None:
    """Record which tools (name+args) solved this request, for instant replay later.
    Call only after a run that actually finished (not one that hit the step limit)."""
    if not tool_calls:
        return
    key = normalize(transcript)
    if not key:
        return
    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO recipes (normalized_text, transcript, tool_calls_json, final_text, updated_ts, hits)
            VALUES (?, ?, ?, ?, ?, 0)
            ON CONFLICT(normalized_text) DO UPDATE SET
                transcript=excluded.transcript,
                tool_calls_json=excluded.tool_calls_json,
                final_text=excluded.final_text,
                updated_ts=excluded.updated_ts
            """,
            (key, transcript, json.dumps(tool_calls, ensure_ascii=False), final_text, time.time()),
        )


def find_recipe(transcript: str) -> dict | None:
    """Exact (normalized) match first; otherwise the closest stored recipe above
    JARVIS_RECIPE_MATCH. Returns {"tool_calls": [...], "final_text": str} or None."""
    key = normalize(transcript)
    if not key:
        return None
    with _connect() as conn:
        row = conn.execute(
            "SELECT tool_calls_json, final_text FROM recipes WHERE normalized_text = ?",
            (key,),
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE recipes SET hits = hits + 1 WHERE normalized_text = ?", (key,)
            )
            return {"tool_calls": json.loads(row[0]), "final_text": row[1]}

        if RECIPE_MATCH_THRESHOLD >= 1.0:
            return None
        best_key, best_ratio = None, 0.0
        for (candidate,) in conn.execute("SELECT normalized_text FROM recipes").fetchall():
            ratio = difflib.SequenceMatcher(None, key, candidate).ratio()
            if ratio > best_ratio:
                best_key, best_ratio = candidate, ratio
        if best_key is None or best_ratio < RECIPE_MATCH_THRESHOLD:
            return None
        row = conn.execute(
            "SELECT tool_calls_json, final_text FROM recipes WHERE normalized_text = ?",
            (best_key,),
        ).fetchone()
        if not row:
            return None
        conn.execute("UPDATE recipes SET hits = hits + 1 WHERE normalized_text = ?", (best_key,))
        return {"tool_calls": json.loads(row[0]), "final_text": row[1]}


def clear() -> int:
    """Wipes all stored turns and recipes. Returns how many turn rows were deleted."""
    with _connect() as conn:
        cur = conn.execute("DELETE FROM turns")
        conn.execute("DELETE FROM recipes")
        return cur.rowcount


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--clear":
        print(f"Borradas {clear()} entradas de {DB_PATH}")
    else:
        for m in load_recent_as_messages():
            print(f"[{m['role']}] {m['content'][:200]}")