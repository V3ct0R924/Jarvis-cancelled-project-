from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import wave
import webbrowser
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
import numpy as np
import sounddevice as sd

SAMPLE_RATE = 44100
BLOCK_MS = 40
CHANNELS = 1

SPIKE_RATIO = 7.0
COOLDOWN_S = 0.45
MIN_DOUBLE_GAP_S = 0.05
MAX_DOUBLE_GAP_S = 0.35
RETRIGGER_RATIO = 0.55
NOISE_FLOOR_ALPHA = 0.992
MIN_RMS = 0.012
QUIET_GATE_MULT = 2.2

INPUT_PROBE_S = 0.5
INPUT_SILENT_RMS = 0.001

SONG_URI = "https://open.spotify.com/track/39shmbIHICJ2Wxnk1fPSdz?si=2900c75c2e2d4b82"

FOCUS_EXISTING_CURSOR_ON_DOUBLE_CLAP = True
OPEN_NEW_CURSOR_ON_DOUBLE_CLAP = False
CURSOR_OPEN_FULLSCREEN = True

CHROME_OPEN_AS_NEW_TAB = True

OPEN_CLAUDE_CODE_IN_CHROME = True
OPEN_BINANCE_BTC_IN_CHROME = True
OPEN_CHROME_FULLSCREEN = True

CHROME_SEPARATE_SITE_PROFILES = False

CLAUDE_CHROME_MONITOR = 1
BINANCE_CHROME_MONITOR = 3

JARVIS_WELCOME_ENABLED = True
JARVIS_WELCOME_PHRASE = (
    "Welcome home sir. "
    "Congratulations on the new client for your SaaS app—make sure to follow up. "
    "If it helps: a short, specific note while the deal is still fresh usually "
    "anchors trust better than a polished deck sent cold a few days later."
)

JARVIS_AFTER_SONG_DELAY_S = 1.0

JARVIS_WELCOME_CACHE_ENABLED = True

JARVIS_AI_ENABLED = True
JARVIS_AI_DYNAMIC_WELCOME = True
JARVIS_VOICE_COMMANDS_ENABLED = True

JARVIS_VOICE_COMMAND_MODE = os.environ.get("JARVIS_VOICE_COMMAND_MODE", "mcp_agent").strip().lower()

NVIDIA_MODEL = os.environ.get("NVIDIA_MODEL", "nvidia/nemotron-3-ultra-550b-a55b")
NVIDIA_BASE_URL = os.environ.get(
    "NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1"
)
NVIDIA_TIMEOUT_S = float(os.environ.get("NVIDIA_TIMEOUT_S", "20"))

NEMOTRON_ENABLE_THINKING = os.environ.get("NEMOTRON_ENABLE_THINKING", "false").strip().lower() in (
    "1", "true", "yes",
)

VOICE_COMMAND_RECORD_S = 4.0

VOICE_COMMAND_LANGUAGE = os.environ.get("JARVIS_LANGUAGE", "es-AR").strip()
JARVIS_TTS_LANGUAGE_CODE = VOICE_COMMAND_LANGUAGE.split("-")[0].lower()

JARVIS_TRIGGER_MODE = os.environ.get("JARVIS_TRIGGER_MODE", "wakeword").strip().lower()

JARVIS_HOTKEY = os.environ.get("JARVIS_HOTKEY", "ctrl+alt+space").strip()
JARVIS_TEXT_HOTKEY = os.environ.get("JARVIS_TEXT_HOTKEY", "ctrl+alt+t").strip()

WAKEWORD_NAME = os.environ.get("JARVIS_WAKEWORD", "hey_jarvis").strip().lower()
WAKEWORD_THRESHOLD = float(os.environ.get("JARVIS_WAKEWORD_THRESHOLD", "0.5"))
WAKEWORD_COMMAND_MAX_S = float(os.environ.get("JARVIS_WAKEWORD_MAX_S", "60"))
WAKEWORD_SILENCE_HANG_S = float(os.environ.get("JARVIS_WAKEWORD_SILENCE_HANG_S", "1.5"))

JARVIS_ACK_PHRASES = [
    "¿Sí, señor?",
    "Dígame.",
    "Lo escucho.",
    "¿En qué lo ayudo?",
    "A la orden.",
    "Usted dirá.",
]
JARVIS_CANCEL_PHRASES = [
    "Entendido, señor.",
    "Como diga.",
    "De acuerdo, quedamos así.",
    "Ahí queda, entonces.",
    "Perfecto, cancelado.",
]
JARVIS_START_PHRASES = [
    "Okey señor, ya me pongo con eso.",
    "Dale, ahí voy.",
    "Entendido, procedo.",
    "Bien, ya arranco.",
    "Perfecto, un momento.",
    "Enseguida, señor.",
]

_CANCEL_WORDS = {
    "nada", "nada mas", "cancelar", "cancela", "cancela eso", "olvidalo",
    "dejalo", "dejalo asi", "no importa", "nada gracias", "no, nada",
    "no era nada", "mentira", "era mentira",
}

def _normalize_for_match(text: str) -> str:
    import unicodedata

    t = unicodedata.normalize("NFKD", text or "")
    t = "".join(c for c in t if not unicodedata.combining(c))
    return " ".join(t.lower().split()).strip(" .,!¡?¿")

load_dotenv(Path(__file__).resolve().parent / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("clap_listen")

def block_samples() -> int:
    n = int(SAMPLE_RATE * BLOCK_MS / 1000)
    return max(n, 1)

def rms_mono(block: np.ndarray) -> float:
    if block.ndim > 1:
        block = np.mean(block.astype(np.float64), axis=1)
    else:
        block = block.astype(np.float64)
    if block.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(block**2)))

def _input_devices() -> list[tuple[int, dict]]:
    return [
        (i, dev)
        for i, dev in enumerate(sd.query_devices())
        if dev["max_input_channels"] >= 1
    ]

def _resolve_input_device_index(spec: str) -> int:
    spec = spec.strip()
    if spec.isdigit():
        idx = int(spec)
        sd.query_devices(idx)
        return idx
    needle = spec.lower()
    for idx, dev in _input_devices():
        if needle in dev["name"].lower():
            return idx
    raise ValueError(f"No input device matches {spec!r}")

def _probe_input_max_rms(device: int, blocksize: int) -> float | None:
    try:
        with sd.InputStream(
            device=device,
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype="float32",
            blocksize=blocksize,
        ) as stream:
            peak = 0.0
            deadline = time.monotonic() + INPUT_PROBE_S
            while time.monotonic() < deadline:
                data, _ = stream.read(blocksize)
                peak = max(peak, rms_mono(data))
            return peak
    except sd.PortAudioError:
        return None

def _choose_input_device(blocksize: int) -> int:
    log.info("Audio devices:\n%s", sd.query_devices())

    override = (os.environ.get("JARVIS_INPUT_DEVICE") or "").strip()
    if override:
        try:
            idx = _resolve_input_device_index(override)
        except ValueError as e:
            log.error("%s", e)
            log.error("Set JARVIS_INPUT_DEVICE to a device index or name substring.")
            raise SystemExit(1) from e
        name = sd.query_devices(idx)["name"]
        peak = _probe_input_max_rms(idx, blocksize)
        log.info("Using JARVIS_INPUT_DEVICE [%d]: %s", idx, name)
        if peak is None:
            log.warning("Could not open configured mic; trying anyway.")
        elif peak < INPUT_SILENT_RMS:
            log.warning(
                "Configured mic looks silent (probe rms=%.5f). "
                "Check Windows input level or try another JARVIS_INPUT_DEVICE.",
                peak,
            )
        else:
            log.info("Mic probe OK (rms=%.5f).", peak)
        return idx

    default = sd.default.device[0]
    if default is not None and default >= 0:
        default_name = sd.query_devices(default)["name"]
        peak = _probe_input_max_rms(default, blocksize)
        if peak is not None and peak >= INPUT_SILENT_RMS:
            log.info(
                "Using default microphone [%d]: %s (probe rms=%.5f)",
                default,
                default_name,
                peak,
            )
            return default
        log.warning(
            "Default mic [%d] %s is silent or unavailable (probe rms=%s); "
            "scanning other inputs...",
            default,
            default_name,
            f"{peak:.5f}" if peak is not None else "unopenable",
        )

    best_idx: int | None = None
    best_peak = -1.0
    for idx, dev in _input_devices():
        if default is not None and idx == default:
            continue
        peak = _probe_input_max_rms(idx, blocksize)
        if peak is not None and peak > best_peak:
            best_peak = peak
            best_idx = idx

    if best_idx is not None and best_peak >= INPUT_SILENT_RMS:
        log.info(
            "Auto-selected microphone [%d]: %s (probe rms=%.5f)",
            best_idx,
            sd.query_devices(best_idx)["name"],
            best_peak,
        )
        return best_idx

    if default is not None and default >= 0:
        log.warning("No active mic found; falling back to default [%d].", default)
        return default
    inputs = _input_devices()
    if not inputs:
        log.error("No input devices found.")
        raise SystemExit(1)
    idx, dev = inputs[0]
    log.warning("No active mic found; falling back to [%d] %s.", idx, dev["name"])
    return idx

def _elevenlabs_pcm_sample_rate(output_format: str) -> int:
    override = (os.environ.get("ELEVENLABS_PCM_SAMPLE_RATE") or "").strip()
    if override.isdigit():
        return int(override)
    if output_format.startswith("pcm_"):
        try:
            return int(output_format.split("_", maxsplit=1)[1])
        except (ValueError, IndexError):
            pass
    return 24000

def elevenlabs_env_config() -> tuple[str, str, str, int]:
    voice = (os.environ.get("ELEVENLABS_VOICE_ID") or "").strip()
    model = (os.environ.get("ELEVENLABS_MODEL_ID") or "eleven_multilingual_v2").strip()
    fmt = (os.environ.get("ELEVENLABS_OUTPUT_FORMAT") or "pcm_24000").strip()
    rate = _elevenlabs_pcm_sample_rate(fmt)
    return voice, model, fmt, rate

def _jarvis_welcome_cache_dir() -> Path:
    base = Path(__file__).resolve().parent
    override = (os.environ.get("JARVIS_WELCOME_CACHE_DIR") or "").strip()
    if override:
        return Path(override).expanduser().resolve()
    return base / ".cache" / "jarvis_welcome"

def _jarvis_welcome_cache_path(
    text: str, voice_id: str, model_id: str, output_format: str
) -> Path:
    key = f"{text}|{voice_id}|{model_id}|{output_format}".encode()
    digest = hashlib.sha256(key).hexdigest()[:24]
    return _jarvis_welcome_cache_dir() / f"{digest}.wav"

def _play_pcm_wav_file(path: Path) -> bool:
    try:
        with wave.open(str(path), "rb") as wf:
            ch = wf.getnchannels()
            sw = wf.getsampwidth()
            rate = wf.getframerate()
            if ch != 1 or sw != 2:
                log.warning("Unsupported cached WAV (channels=%s, width=%s).", ch, sw)
                return False
            raw = wf.readframes(wf.getnframes())
    except (OSError, wave.Error) as e:
        log.warning("Could not read cached welcome audio: %s", e)
        return False
    if not raw:
        return False
    pcm_i16 = np.frombuffer(raw, dtype=np.int16)
    pcm_f = pcm_i16.astype(np.float32) / 32768.0
    try:
        sd.play(pcm_f, rate)
        sd.wait()
    except Exception as e:
        log.warning("Could not play cached welcome audio: %s", e)
        return False
    return True

def _save_pcm_wav_file(path: Path, pcm_bytes: bytes, sample_rate: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with wave.open(str(tmp), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm_bytes)
        tmp.replace(path)
    except OSError:
        if tmp.is_file():
            tmp.unlink(missing_ok=True)
        raise

def nvidia_chat(
    messages: list[dict],
    *,
    max_tokens: int = 300,
    temperature: float = 0.6,
) -> str | None:
    if not JARVIS_AI_ENABLED:
        return None
    api_key = (os.environ.get("NVIDIA_API_KEY") or "").strip()
    if not api_key:
        log.warning("Set NVIDIA_API_KEY in the environment/.env to use Nemotron.")
        return None
    try:
        import requests
    except ImportError:
        log.warning("Install dependencies: pip install -r requirements.txt (needs `requests`)")
        return None
    try:
        resp = requests.post(
            f"{NVIDIA_BASE_URL.rstrip('/')}/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": NVIDIA_MODEL,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "chat_template_kwargs": {"enable_thinking": NEMOTRON_ENABLE_THINKING},
            },
            timeout=NVIDIA_TIMEOUT_S,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        log.warning("Nemotron request failed: %s", e)
        return None

def generate_dynamic_welcome() -> str:
    fallback = JARVIS_WELCOME_PHRASE.strip()
    if not JARVIS_AI_DYNAMIC_WELCOME:
        return fallback
    now = datetime.now()
    prompt = (
        "You are Jarvis, a witty but concise voice assistant welcoming your user back "
        f"after a double clap. Local time: {now:%A %H:%M}. "
        "Write ONE short spoken line (max 2 sentences), address them as 'sir', "
        "no markdown, no quotation marks, just the plain spoken text."
    )
    content = nvidia_chat(
        [{"role": "user", "content": prompt}], max_tokens=120, temperature=0.9
    )
    if content and content.strip():
        return content.strip().strip('"')
    log.warning("Nemotron unavailable; using the fixed JARVIS_WELCOME_PHRASE instead.")
    return fallback

def _record_command_audio(seconds: float, device: int) -> np.ndarray | None:
    frames = max(int(SAMPLE_RATE * seconds), 1)
    try:
        audio = sd.rec(
            frames, samplerate=SAMPLE_RATE, channels=CHANNELS, dtype="float32", device=device
        )
        sd.wait()
    except sd.PortAudioError as e:
        log.warning("Could not record voice command: %s", e)
        return None
    return audio

def _record_until_silence(
    device: int, max_seconds: float = 60.0, silence_hang_s: float = 1.5
) -> np.ndarray | None:
    block_ms = 100
    block_frames = max(int(SAMPLE_RATE * block_ms / 1000), 1)
    silence_blocks_needed = max(1, int(round(silence_hang_s * 1000 / block_ms)))
    max_blocks = max(1, int(round(max_seconds * 1000 / block_ms)))

    chunks: list[np.ndarray] = []
    silence_streak = 0
    heard_speech = False
    noise_floor = 1e-4

    try:
        with sd.InputStream(
            device=device,
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype="float32",
            blocksize=block_frames,
        ) as stream:
            for _ in range(max_blocks):
                data, _ = stream.read(block_frames)
                chunks.append(data.copy())
                level = rms_mono(data)
                threshold = max(noise_floor * 4.0, MIN_RMS)
                if level < threshold:
                    noise_floor = 0.98 * noise_floor + 0.02 * level
                    noise_floor = max(noise_floor, 1e-7)
                    silence_streak += 1
                    if heard_speech and silence_streak >= silence_blocks_needed:
                        break
                else:
                    heard_speech = True
                    silence_streak = 0
    except sd.PortAudioError as e:
        log.warning("Could not record voice command: %s", e)
        return None

    if not chunks:
        return None
    return np.concatenate(chunks, axis=0)

def transcribe_command(audio: np.ndarray) -> str | None:
    try:
        import speech_recognition as sr
    except ImportError:
        log.warning(
            "Install dependencies: pip install -r requirements.txt (needs `SpeechRecognition`)"
        )
        return None
    pcm_i16 = np.clip(audio.reshape(-1) * 32767.0, -32768, 32767).astype(np.int16)
    tmp_path = Path(tempfile.mktemp(suffix=".wav"))
    try:
        _save_pcm_wav_file(tmp_path, pcm_i16.tobytes(), SAMPLE_RATE)
        recognizer = sr.Recognizer()
        with sr.AudioFile(str(tmp_path)) as source:
            audio_data = recognizer.record(source)
        try:
            return recognizer.recognize_google(audio_data, language=VOICE_COMMAND_LANGUAGE)
        except sr.UnknownValueError:
            log.info("Voice command: nothing understood.")
            return None
        except sr.RequestError as e:
            log.warning("Speech recognition request failed: %s", e)
            return None
    finally:
        tmp_path.unlink(missing_ok=True)

def interpret_voice_command(transcript: str) -> list[str]:
    known = ", ".join(ACTIONS.keys())
    system = (
        "You route spoken commands for a desktop assistant to a fixed set of actions: "
        f"{known}. Reply with ONLY a JSON array of action names to run, in order, chosen "
        'strictly from that set, e.g. ["open_claude"]. If none apply, reply with [].'
    )
    content = nvidia_chat(
        [{"role": "system", "content": system}, {"role": "user", "content": transcript}],
        max_tokens=60,
        temperature=0.0,
    )
    if not content:
        return []
    cleaned = content.strip().strip("`")
    if cleaned.lower().startswith("json"):
        cleaned = cleaned[4:].strip()
    try:
        actions = json.loads(cleaned)
    except (ValueError, TypeError):
        log.warning("Could not parse Nemotron's action list: %r", content)
        return []
    if not isinstance(actions, list):
        return []
    return [a for a in actions if isinstance(a, str) and a in ACTIONS]

def _elevenlabs_tts_bytes(text: str, vid: str, model_id: str, output_format: str) -> bytes | None:
    api_key = (os.environ.get("ELEVENLABS_API_KEY") or "").strip()
    if not api_key:
        log.warning("Set ELEVENLABS_API_KEY in the environment for ElevenLabs TTS.")
        return None
    try:
        from elevenlabs.client import ElevenLabs
    except ImportError:
        log.warning("Install dependencies: pip install -r requirements.txt")
        return None
    try:
        client = ElevenLabs(api_key=api_key)
        try:
            chunks = client.text_to_speech.convert(
                voice_id=vid,
                text=text,
                model_id=model_id,
                output_format=output_format,
                language_code=JARVIS_TTS_LANGUAGE_CODE,
            )
            raw = b"".join(chunks)
        except TypeError:
            chunks = client.text_to_speech.convert(
                voice_id=vid, text=text, model_id=model_id, output_format=output_format
            )
            raw = b"".join(chunks)
    except Exception as e:
        log.warning("ElevenLabs TTS failed: %s", e)
        return None
    if not raw:
        log.warning("ElevenLabs returned empty audio.")
        return None
    return raw

def _play_pcm_bytes(raw: bytes, pcm_rate: int) -> None:
    pcm_i16 = np.frombuffer(raw, dtype=np.int16)
    pcm_f = pcm_i16.astype(np.float32) / 32768.0
    try:
        sd.play(pcm_f, pcm_rate)
        sd.wait()
    except Exception as e:
        log.warning("Could not play ElevenLabs audio: %s", e)

def speak_text(text: str) -> None:
    text = (text or "").strip()
    if not text:
        return
    vid, model_id, output_format, pcm_rate = elevenlabs_env_config()
    if not vid:
        log.warning("Set ELEVENLABS_VOICE_ID in the environment for ElevenLabs TTS.")
        return
    raw = _elevenlabs_tts_bytes(text, vid, model_id, output_format)
    if raw:
        _play_pcm_bytes(raw, pcm_rate)

def say_jarvis_welcome() -> None:
    if not JARVIS_WELCOME_ENABLED:
        return
    text = generate_dynamic_welcome() if JARVIS_AI_DYNAMIC_WELCOME else JARVIS_WELCOME_PHRASE.strip()
    if not text:
        return
    vid, model_id, output_format, pcm_rate = elevenlabs_env_config()
    if not vid:
        log.warning("Set ELEVENLABS_VOICE_ID in the environment for ElevenLabs TTS.")
        return

    cache_enabled = JARVIS_WELCOME_CACHE_ENABLED and not JARVIS_AI_DYNAMIC_WELCOME
    cache_path = _jarvis_welcome_cache_path(text, vid, model_id, output_format)
    if cache_enabled and cache_path.is_file():
        log.info("Playing welcome from cache: %s", cache_path)
        if _play_pcm_wav_file(cache_path):
            return
        log.warning("Cache miss after read failure; fetching from ElevenLabs.")

    raw = _elevenlabs_tts_bytes(text, vid, model_id, output_format)
    if not raw:
        return
    if cache_enabled:
        try:
            _save_pcm_wav_file(cache_path, raw, pcm_rate)
            log.info("Saved welcome audio to cache: %s", cache_path)
        except OSError as e:
            log.warning("Could not save welcome cache: %s", e)
    _play_pcm_bytes(raw, pcm_rate)

def play_song(uri: str) -> None:
    u = uri.strip()
    if not u:
        return
    try:
        if sys.platform == "win32":
            os.startfile(u)
        else:
            webbrowser.open(u)
    except OSError as e:
        log.warning("Could not open SONG_URI: %s", e)

def _chrome_executable() -> str | None:
    if sys.platform == "win32":
        for base in (
            os.environ.get("ProgramFiles", r"C:\Program Files"),
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ):
            if not base:
                continue
            p = os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")
            if os.path.isfile(p):
                return p
    return shutil.which("google-chrome") or shutil.which("chrome")

def _win32_sorted_monitor_rects() -> list[tuple[int, int, int, int]]:
    if sys.platform != "win32":
        return []
    import ctypes
    from ctypes import wintypes

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", wintypes.LONG),
            ("top", wintypes.LONG),
            ("right", wintypes.LONG),
            ("bottom", wintypes.LONG),
        ]

    collected: list[tuple[int, int, int, int]] = []

    @ctypes.WINFUNCTYPE(
        wintypes.BOOL,
        wintypes.HMONITOR,
        wintypes.HDC,
        ctypes.POINTER(RECT),
        wintypes.LPARAM,
    )
    def _cb(_hm, _hdc, lprc, _lp):
        r = lprc.contents
        collected.append((int(r.left), int(r.top), int(r.right), int(r.bottom)))
        return True

    ctypes.windll.user32.EnumDisplayMonitors(None, None, _cb, 0)
    collected.sort(key=lambda t: (t[0], t[1]))
    return collected

def _chrome_monitor_top_left(one_based_index: int) -> tuple[int, int]:
    l, t, _, _ = _chrome_monitor_bounds(one_based_index)
    return (l, t)

def _chrome_monitor_bounds(one_based_index: int) -> tuple[int, int, int, int]:
    rects = _win32_sorted_monitor_rects()
    if not rects:
        return (0, 0, 1920, 1080)
    idx = one_based_index - 1
    if idx < 0:
        idx = 0
    if idx >= len(rects):
        log.warning(
            "Monitor %d requested but only %d found; using last monitor.",
            one_based_index,
            len(rects),
        )
        idx = len(rects) - 1
    return rects[idx]

def _chrome_monitor_pixel_size(one_based_index: int) -> tuple[int, int]:
    l, t, r, b = _chrome_monitor_bounds(one_based_index)
    return (max(320, r - l), max(240, b - t))

def _chrome_window_size() -> tuple[int, int]:
    w = (os.environ.get("CHROME_WINDOW_WIDTH") or "1400").strip()
    h = (os.environ.get("CHROME_WINDOW_HEIGHT") or "900").strip()
    try:
        return (max(400, int(w)), max(300, int(h)))
    except ValueError:
        return (1400, 900)

def _chrome_site_user_data_dir(site_key: str) -> str:
    p = Path(tempfile.gettempdir()) / "clap-trigger-chrome" / site_key
    p.mkdir(parents=True, exist_ok=True)
    return str(p)

def _chrome_new_window_wait_timeout_s() -> float:
    try:
        return max(3.0, float((os.environ.get("CHROME_NEW_WINDOW_WAIT_S") or "25").strip()))
    except ValueError:
        return 25.0

def _chrome_top_level_browser_hwnds_win32() -> set[int]:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    GW_OWNER = 4
    GWL_EXSTYLE = -20
    WS_EX_TOOLWINDOW = 0x00000080
    found: set[int] = set()

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _enum(hwnd: wintypes.HWND, _lp: wintypes.LPARAM) -> bool:
        if user32.GetWindow(hwnd, GW_OWNER):
            return True
        if user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW:
            return True
        if not user32.IsWindowVisible(hwnd) and not user32.IsIconic(hwnd):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == 0:
            return True
        hproc = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not hproc:
            return True
        try:
            buf = ctypes.create_unicode_buffer(4096)
            sz = wintypes.DWORD(len(buf))
            if not kernel32.QueryFullProcessImageNameW(hproc, 0, buf, ctypes.byref(sz)):
                return True
            exe_path = buf.value
        finally:
            kernel32.CloseHandle(hproc)
        if os.path.basename(exe_path).lower() != "chrome.exe":
            return True
        r = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return True
        w, h = r.right - r.left, r.bottom - r.top
        if w < 80 or h < 80:
            return True
        found.add(int(hwnd))
        return True

    user32.EnumWindows(_enum, 0)
    return found

def _wait_new_chrome_hwnd_win32(before: set[int], timeout: float) -> int | None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        time.sleep(0.12)
        now = _chrome_top_level_browser_hwnds_win32()
        new = now - before
        if not new:
            continue
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        best: int | None = None
        best_area = 0
        for h in new:
            r = wintypes.RECT()
            if user32.GetWindowRect(h, ctypes.byref(r)):
                a = max(0, r.right - r.left) * max(0, r.bottom - r.top)
                if a > best_area:
                    best_area = a
                    best = h
        if best is not None:
            return best
    return None

def _chrome_snap_window_to_monitor_win32(
    hwnd: int,
    one_based_monitor: int,
    *,
    fullscreen: bool,
    windowed_size: tuple[int, int] | None,
) -> None:
    import ctypes
    from ctypes import wintypes

    ml, mt, mr, mb = _chrome_monitor_bounds(one_based_monitor)
    user32 = ctypes.windll.user32
    SW_RESTORE = 9
    SW_SHOWMAXIMIZED = 3
    HWND_TOP = 0
    SWP_SHOWWINDOW = 0x0040
    SWP_FRAMECHANGED = 0x0020
    flags = SWP_SHOWWINDOW | SWP_FRAMECHANGED

    user32.ShowWindow(hwnd, SW_RESTORE)
    if fullscreen:
        w, h = mr - ml, mb - mt
        x, y = ml, mt
    else:
        ww, wh = windowed_size or _chrome_window_size()
        w, h = ww, wh
        x = ml + max(0, (mr - ml - w) // 2)
        y = mt + max(0, (mb - mt - h) // 2)
    user32.SetWindowPos(hwnd, HWND_TOP, x, y, w, h, flags)

    if fullscreen:
        user32.ShowWindow(hwnd, SW_SHOWMAXIMIZED)
        KEYEVENTF_KEYUP = 0x0002
        VK_F11 = 0x7A
        fg = user32.GetForegroundWindow()
        tid_tgt = user32.GetWindowThreadProcessId(hwnd, None)
        tid_fg = user32.GetWindowThreadProcessId(fg, None) if fg else 0
        if tid_fg and tid_tgt:
            user32.AttachThreadInput(tid_fg, tid_tgt, True)
        user32.SetForegroundWindow(hwnd)
        if tid_fg and tid_tgt:
            user32.AttachThreadInput(tid_fg, tid_tgt, False)
        user32.keybd_event(VK_F11, 0, 0, 0)
        user32.keybd_event(VK_F11, 0, KEYEVENTF_KEYUP, 0)

def _open_url_in_chrome(
    url: str,
    *,
    new_window: bool = True,
    label: str = "URL",
    window_position: tuple[int, int] | None = None,
    window_size: tuple[int, int] | None = None,
    fullscreen: bool = False,
    win32_post_fullscreen_monitor: int | None = None,
    user_data_dir: str | None = None,
) -> None:
    u = url.strip()
    if not u:
        return
    chrome = _chrome_executable()
    try:
        if chrome:
            args = [chrome]
            if user_data_dir:
                args.append(f"--user-data-dir={user_data_dir}")
                args.append("--no-first-run")
            if new_window:
                args.append("--new-window")
            if window_position is not None:
                x, y = window_position
                args.append(f"--window-position={x},{y}")
            if window_size:
                args.append(f"--window-size={window_size[0]},{window_size[1]}")
            if fullscreen and not (
                sys.platform == "win32" and win32_post_fullscreen_monitor is not None
            ):
                args.append("--start-fullscreen")
            args.append(u)
            popen_kw: dict = {
                "args": args,
                "stdin": subprocess.DEVNULL,
                "stdout": subprocess.DEVNULL,
                "stderr": subprocess.DEVNULL,
            }
            if sys.platform == "win32":
                popen_kw["creationflags"] = subprocess.CREATE_NO_WINDOW
            before: set[int] | None = None
            if sys.platform == "win32" and win32_post_fullscreen_monitor is not None:
                before = _chrome_top_level_browser_hwnds_win32()
            subprocess.Popen(**popen_kw)
            if sys.platform == "win32" and win32_post_fullscreen_monitor is not None:
                mon = win32_post_fullscreen_monitor
                hwnd = _wait_new_chrome_hwnd_win32(before, _chrome_new_window_wait_timeout_s())
                if hwnd is not None:
                    _chrome_snap_window_to_monitor_win32(
                        hwnd,
                        mon,
                        fullscreen=fullscreen,
                        windowed_size=window_size if not fullscreen else None,
                    )
                else:
                    log.warning(
                        "Chrome: timed out waiting for new window (%s); check "
                        "CHROME_NEW_WINDOW_WAIT_S or close extra Chrome instances.",
                        label,
                    )
        else:
            log.warning("Chrome not found; opening %s in default browser.", label)
            webbrowser.open(u)
    except OSError as e:
        log.warning("Could not open %s in Chrome: %s", label, e)

def open_claude_in_chrome() -> None:
    if not OPEN_CLAUDE_CODE_IN_CHROME:
        return
    url = (os.environ.get("CLAUDE_CODE_URL") or "https://claude.ai/new").strip()
    if CHROME_OPEN_AS_NEW_TAB:
        _open_url_in_chrome(url, new_window=False, label="Claude")
        return
    pos: tuple[int, int] | None = None
    size: tuple[int, int] | None = None
    fs = OPEN_CHROME_FULLSCREEN
    post_mon: int | None = None
    user_data: str | None = None
    if sys.platform == "win32":
        post_mon = CLAUDE_CHROME_MONITOR
        pos = _chrome_monitor_top_left(CLAUDE_CHROME_MONITOR)
        if fs:
            size = _chrome_monitor_pixel_size(CLAUDE_CHROME_MONITOR)
        else:
            size = _chrome_window_size()
        if CHROME_SEPARATE_SITE_PROFILES:
            user_data = _chrome_site_user_data_dir("claude")
    elif not fs:
        size = _chrome_window_size()
    else:
        size = None
    _open_url_in_chrome(
        url,
        new_window=True,
        label="Claude",
        window_position=pos,
        window_size=size,
        fullscreen=fs,
        win32_post_fullscreen_monitor=post_mon,
        user_data_dir=user_data,
    )

def open_binance_btc_in_chrome() -> None:
    if not OPEN_BINANCE_BTC_IN_CHROME:
        return
    url = (
        os.environ.get("BINANCE_BTC_URL")
        or "https://www.binance.com/en/trade/BTC_USDT"
    ).strip()
    if CHROME_OPEN_AS_NEW_TAB:
        _open_url_in_chrome(url, new_window=False, label="Binance BTC")
        return
    pos: tuple[int, int] | None = None
    size: tuple[int, int] | None = None
    fs = OPEN_CHROME_FULLSCREEN
    post_mon: int | None = None
    user_data: str | None = None
    if sys.platform == "win32":
        post_mon = BINANCE_CHROME_MONITOR
        pos = _chrome_monitor_top_left(BINANCE_CHROME_MONITOR)
        if fs:
            size = _chrome_monitor_pixel_size(BINANCE_CHROME_MONITOR)
        else:
            size = _chrome_window_size()
        if CHROME_SEPARATE_SITE_PROFILES:
            user_data = _chrome_site_user_data_dir("binance")
    elif not fs:
        size = _chrome_window_size()
    else:
        size = None
    _open_url_in_chrome(
        url,
        new_window=True,
        label="Binance BTC",
        window_position=pos,
        window_size=size,
        fullscreen=fs,
        win32_post_fullscreen_monitor=post_mon,
        user_data_dir=user_data,
    )

def _cursor_executable() -> str | None:
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA", "")
        for sub in ("Programs\\cursor\\Cursor.exe", "Programs\\Cursor\\Cursor.exe"):
            if local:
                p = os.path.join(local, *sub.split("\\"))
                if os.path.isfile(p):
                    return p
    return shutil.which("cursor")

def _cursor_largest_main_hwnd_win32() -> int | None:
    if sys.platform != "win32":
        return None
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    GW_OWNER = 4
    GWL_EXSTYLE = -20
    WS_EX_TOOLWINDOW = 0x00000080
    candidates: list[tuple[int, wintypes.HWND]] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _enum(hwnd: wintypes.HWND, _lp: wintypes.LPARAM) -> bool:
        if user32.GetWindow(hwnd, GW_OWNER):
            return True
        if user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW:
            return True
        if not user32.IsWindowVisible(hwnd) and not user32.IsIconic(hwnd):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == 0:
            return True
        hproc = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not hproc:
            return True
        try:
            buf = ctypes.create_unicode_buffer(4096)
            sz = wintypes.DWORD(len(buf))
            if not kernel32.QueryFullProcessImageNameW(hproc, 0, buf, ctypes.byref(sz)):
                return True
            exe_path = buf.value
        finally:
            kernel32.CloseHandle(hproc)
        if os.path.basename(exe_path).lower() != "cursor.exe":
            return True
        r = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return True
        w, h = r.right - r.left, r.bottom - r.top
        if w < 200 or h < 200:
            return True
        candidates.append((w * h, hwnd))
        return True

    user32.EnumWindows(_enum, 0)
    if not candidates:
        return None
    return int(max(candidates, key=lambda t: t[0])[1])

def _cursor_foreground_hwnd_win32(hwnd: int) -> None:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    SW_RESTORE = 9
    user32.ShowWindow(hwnd, SW_RESTORE)
    fg = user32.GetForegroundWindow()
    tid_tgt = user32.GetWindowThreadProcessId(hwnd, None)
    tid_fg = user32.GetWindowThreadProcessId(fg, None) if fg else 0
    if tid_fg and tid_tgt:
        user32.AttachThreadInput(tid_fg, tid_tgt, True)
    user32.SetForegroundWindow(hwnd)
    if tid_fg and tid_tgt:
        user32.AttachThreadInput(tid_fg, tid_tgt, False)

def _cursor_send_f11_fullscreen_win32(hwnd: int) -> None:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    KEYEVENTF_KEYUP = 0x0002
    VK_F11 = 0x7A
    _cursor_foreground_hwnd_win32(hwnd)
    user32.keybd_event(VK_F11, 0, 0, 0)
    user32.keybd_event(VK_F11, 0, KEYEVENTF_KEYUP, 0)

def _focus_existing_cursor_window_win32() -> bool:
    if sys.platform != "win32":
        return False
    hwnd = _cursor_largest_main_hwnd_win32()
    if hwnd is None:
        return False
    _cursor_foreground_hwnd_win32(hwnd)
    return True

def _speak_welcome_after_delay() -> None:
    if not JARVIS_WELCOME_ENABLED:
        return
    if not (JARVIS_AI_DYNAMIC_WELCOME or JARVIS_WELCOME_PHRASE.strip()):
        return
    delay = max(0.0, JARVIS_AFTER_SONG_DELAY_S)
    if delay:
        time.sleep(delay)
    threading.Thread(target=say_jarvis_welcome, daemon=True).start()

def run_double_clap_actions(input_device: int) -> None:
    if not (JARVIS_VOICE_COMMANDS_ENABLED and JARVIS_AI_ENABLED):
        log.warning(
            "JARVIS_VOICE_COMMANDS_ENABLED/JARVIS_AI_ENABLED están apagados — no hay "
            "nada configurado para el trigger de voz."
        )
        return
    log.info("Listening for a voice command (%.1fs)...", VOICE_COMMAND_RECORD_S)
    audio = _record_command_audio(VOICE_COMMAND_RECORD_S, input_device)
    transcript = audio is not None and transcribe_command(audio)
    if transcript:
        log.info("Heard: %r", transcript)
        handle_command(transcript)
        return
    log.info("No te escuché bien — no hice nada. Probá de nuevo.")

def handle_command(transcript: str) -> None:
    if JARVIS_VOICE_COMMAND_MODE == "mcp_agent":
        _run_mcp_agent_command(transcript)
        return
    actions = interpret_voice_command(transcript)
    if actions:
        log.info("Nemotron chose actions: %s", actions)
        for name in actions:
            try:
                ACTIONS[name]()
            except Exception as e:
                log.warning("Action %r failed: %s", name, e)
        return
    log.info("No matching action for %r — no hice nada.", transcript)

def _chat_log(role: str, text: str) -> None:
    try:
        import jarvis_overlay

        jarvis_overlay.append_chat(role, text)
    except ImportError:
        pass

def _run_mcp_agent_command(transcript: str) -> None:
    import random

    try:
        from nemotron_mcp_agent import run_agent_sync
    except ImportError as e:
        log.error(
            "No se pudo importar nemotron_mcp_agent.py (¿está al lado de jarvis.py? "
            "¿instalaste `pip install mcp`?): %s",
            e,
        )
        return
    speak_text(random.choice(JARVIS_START_PHRASES))
    try:
        result = run_agent_sync(transcript)
        log.info("Nemotron (mcp_agent): %s", result)
        speak_text(result)
        _chat_log("Jarvis", result)
    except Exception as e:
        log.exception("El agente MCP falló")
        _chat_log("Jarvis", "Uy, algo falló de mi lado — mirá la consola.")

def open_cursor_window() -> None:
    if not FOCUS_EXISTING_CURSOR_ON_DOUBLE_CLAP and not OPEN_NEW_CURSOR_ON_DOUBLE_CLAP:
        return
    exe = _cursor_executable()
    if not exe:
        log.warning(
            "Could not find Cursor (install app or add the `cursor` command to PATH)."
        )
        return
    popen_kw: dict = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        popen_kw["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        if FOCUS_EXISTING_CURSOR_ON_DOUBLE_CLAP:
            focused = (
                sys.platform == "win32" and _focus_existing_cursor_window_win32()
            )
            if not focused:
                subprocess.Popen([exe], **popen_kw)
        if OPEN_NEW_CURSOR_ON_DOUBLE_CLAP:
            subprocess.Popen([exe, "-n"], **popen_kw)
    except OSError as e:
        log.warning("Could not start or focus Cursor: %s", e)
        return
    if sys.platform == "win32" and CURSOR_OPEN_FULLSCREEN:
        time.sleep(0.5)
        hwnd = _cursor_largest_main_hwnd_win32()
        if hwnd is not None:
            _cursor_send_f11_fullscreen_win32(hwnd)
        else:
            log.warning("Cursor fullscreen: no Cursor window found to send F11.")

ACTIONS = {
    "play_song": lambda: play_song(SONG_URI),
    "open_claude": open_claude_in_chrome,
    "open_binance": open_binance_btc_in_chrome,
    "open_cursor": open_cursor_window,
    "say_welcome": _speak_welcome_after_delay,
}

def _run_text_trigger() -> int:
    log.info("Modo texto. Escribí un comando y Enter. 'salir' (o Ctrl+C) para terminar.")
    while True:
        try:
            text = input("\nVos> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            continue
        if text.lower() in {"salir", "exit", "quit", "q"}:
            break
        try:
            handle_command(text)
        except Exception as e:
            log.warning("Error manejando el comando: %s", e)
    log.info("Stopped.")
    return 0

def _prompt_text_command() -> str | None:
    try:
        import tkinter as tk
        from tkinter import simpledialog
    except ImportError:
        log.warning("tkinter no disponible; no se puede mostrar la caja de texto.")
        return None

    result: dict[str, str | None] = {"text": None}

    def _ask() -> None:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        result["text"] = simpledialog.askstring(
            "Jarvis", "Comando:", parent=root
        )
        root.destroy()

    t = threading.Thread(target=_ask, daemon=True)
    t.start()
    t.join()
    return result["text"]

def _open_text_input(busy: threading.Event | None = None) -> None:
    try:
        import jarvis_overlay

        jarvis_overlay.open_chat()
        return
    except ImportError:
        pass

    if busy is not None:
        if busy.is_set():
            log.info("Ya estoy atendiendo algo; ignoro el atajo de texto hasta terminar.")
            return
        busy.set()
    try:
        text = _prompt_text_command()
        if text and text.strip():
            log.info("Texto: %r", text.strip())
            handle_command(text.strip())
        else:
            log.info("Caja de texto cancelada o vacía.")
    except Exception as e:
        log.warning("Trigger de texto falló: %s", e)
    finally:
        if busy is not None:
            busy.clear()

def _handle_wakeword_trigger(input_idx: int) -> None:
    import random

    try:
        import jarvis_overlay

        jarvis_overlay.show()
    except ImportError:
        jarvis_overlay = None

    try:
        speak_text(random.choice(JARVIS_ACK_PHRASES))
        log.info(
            "Escuchando comando (hasta %.0fs, corta solo con %.1fs de silencio)...",
            WAKEWORD_COMMAND_MAX_S,
            WAKEWORD_SILENCE_HANG_S,
        )
        audio = _record_until_silence(
            input_idx, max_seconds=WAKEWORD_COMMAND_MAX_S, silence_hang_s=WAKEWORD_SILENCE_HANG_S
        )
        transcript = audio is not None and transcribe_command(audio)
        normalized = _normalize_for_match(transcript) if transcript else ""
        if not transcript or normalized in _CANCEL_WORDS:
            log.info("Comando cancelado (silencio o palabra de cancelación): %r", transcript)
            speak_text(random.choice(JARVIS_CANCEL_PHRASES))
            return
        log.info("Heard: %r", transcript)
        _chat_log("Vos", transcript)
        handle_command(transcript)
    finally:
        if jarvis_overlay:
            jarvis_overlay.hide()

def _run_wakeword_trigger(input_idx: int) -> int:
    try:
        import openwakeword
        from openwakeword.model import Model
    except ImportError:
        log.error(
            "Install dependencies: pip install -r requirements.txt (needs `openwakeword`)"
        )
        return 1

    try:
        openwakeword.utils.download_models([WAKEWORD_NAME])
    except Exception as e:
        log.warning(
            "No se pudieron descargar/verificar los modelos de openWakeWord (¿sin "
            "internet la primera vez?): %s",
            e,
        )

    try:
        oww_model = Model(wakeword_models=[WAKEWORD_NAME])
    except Exception as e:
        log.error(
            "No se pudo inicializar openWakeWord con el modelo %r: %s",
            WAKEWORD_NAME,
            e,
        )
        return 1

    wake_rate = 16000
    frame_samples = 1280

    log.info(
        "Escuchando la wakeword (modelo %r, decí \"Hey Jarvis\")... Ctrl+C para salir.",
        WAKEWORD_NAME,
    )
    busy = threading.Event()
    armed = True

    def _fire() -> None:
        if busy.is_set():
            log.info("Ya estoy atendiendo algo; ignoro la wakeword hasta terminar.")
            return
        busy.set()
        try:
            _handle_wakeword_trigger(input_idx)
        except Exception as e:
            log.warning("Trigger de wakeword falló: %s", e)
        finally:
            busy.clear()

    try:
        import keyboard

        def _fire_text() -> None:
            _open_text_input(busy)

        keyboard.add_hotkey(
            JARVIS_TEXT_HOTKEY, lambda: threading.Thread(target=_fire_text, daemon=True).start()
        )
        log.info("También podés apretar %s para escribir en vez de hablar.", JARVIS_TEXT_HOTKEY)
    except ImportError:
        log.warning(
            "Falta `keyboard` (pip install -r requirements.txt) — el atajo de texto "
            "%s no va a estar disponible, solo la wakeword.",
            JARVIS_TEXT_HOTKEY,
        )
    except ValueError as e:
        log.warning("Atajo de texto inválido (JARVIS_TEXT_HOTKEY=%r): %s", JARVIS_TEXT_HOTKEY, e)

    try:
        with sd.RawInputStream(
            samplerate=wake_rate,
            blocksize=frame_samples,
            dtype="int16",
            channels=1,
            device=input_idx,
        ) as stream:
            while True:
                pcm_bytes, _ = stream.read(frame_samples)
                frame = np.frombuffer(pcm_bytes, dtype=np.int16)
                predictions = oww_model.predict(frame)
                score = predictions.get(WAKEWORD_NAME, 0.0)
                if score >= 0.15:
                    log.info(
                        "Wakeword score=%.2f (umbral=%.2f)%s",
                        score,
                        WAKEWORD_THRESHOLD,
                        " -> DETECTADA" if score >= WAKEWORD_THRESHOLD else "",
                    )
                if score >= WAKEWORD_THRESHOLD:
                    if armed:
                        armed = False
                        threading.Thread(target=_fire, daemon=True).start()
                else:
                    armed = True
    except KeyboardInterrupt:
        pass
    except sd.PortAudioError as e:
        log.error("Audio error: %s", e)
        return 1
    log.info("Stopped.")
    return 0

def _run_hotkey_trigger(input_idx: int) -> int:
    try:
        import keyboard
    except ImportError:
        log.error(
            "Install dependencies: pip install -r requirements.txt (needs `keyboard`)"
        )
        return 1

    log.info(
        "Press %s for voice, %s for a text prompt. Ctrl+C to stop.",
        JARVIS_HOTKEY,
        JARVIS_TEXT_HOTKEY,
    )
    busy = threading.Event()

    def _fire_voice() -> None:
        if busy.is_set():
            log.info("Already running a request; ignoring extra press.")
            return
        busy.set()
        try:
            run_double_clap_actions(input_idx)
        except Exception as e:
            log.warning("Trigger run failed: %s", e)
        finally:
            busy.clear()

    def _fire_text() -> None:
        _open_text_input(busy)

    def _on_voice_hotkey() -> None:
        threading.Thread(target=_fire_voice, daemon=True).start()

    def _on_text_hotkey() -> None:
        threading.Thread(target=_fire_text, daemon=True).start()

    try:
        keyboard.add_hotkey(JARVIS_HOTKEY, _on_voice_hotkey)
        keyboard.add_hotkey(JARVIS_TEXT_HOTKEY, _on_text_hotkey)
    except ValueError as e:
        log.error(
            "Atajo inválido (JARVIS_HOTKEY=%r / JARVIS_TEXT_HOTKEY=%r): %s",
            JARVIS_HOTKEY,
            JARVIS_TEXT_HOTKEY,
            e,
        )
        return 1

    try:
        keyboard.wait()
    except KeyboardInterrupt:
        pass
    log.info("Stopped.")
    return 0

def _run_clap_trigger(input_idx: int, blocksize: int) -> int:
    noise_floor = 1e-4
    last_logged_double = 0.0
    first_clap_time: float | None = None
    spike_armed = True
    welcome_sequence_done = False

    log.info(
        "Listening (double clap: %.2f–%.2fs apart, rate=%d, block=%d ms, "
        "spike_ratio=%.1f, cooldown=%.2fs). Ctrl+C to stop.",
        MIN_DOUBLE_GAP_S,
        MAX_DOUBLE_GAP_S,
        SAMPLE_RATE,
        BLOCK_MS,
        SPIKE_RATIO,
        COOLDOWN_S,
    )

    try:
        with sd.InputStream(
            device=input_idx,
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype="float32",
            blocksize=blocksize,
        ) as stream:
            while True:
                data, overflowed = stream.read(blocksize)
                if overflowed:
                    log.warning("Input overflow; try a larger BLOCK_MS")

                level = rms_mono(data)

                quiet_gate = noise_floor * QUIET_GATE_MULT
                if level < quiet_gate:
                    noise_floor = NOISE_FLOOR_ALPHA * noise_floor + (
                        1.0 - NOISE_FLOOR_ALPHA
                    ) * level
                    noise_floor = max(noise_floor, 1e-7)

                threshold = max(noise_floor * SPIKE_RATIO, MIN_RMS)
                now = time.monotonic()
                retrigger_level = threshold * RETRIGGER_RATIO

                if level < retrigger_level:
                    spike_armed = True

                if (
                    spike_armed
                    and level >= threshold
                    and (now - last_logged_double) >= COOLDOWN_S
                ):
                    spike_armed = False
                    if first_clap_time is None:
                        first_clap_time = now
                    else:
                        gap = now - first_clap_time
                        if gap < MIN_DOUBLE_GAP_S:
                            pass
                        elif gap <= MAX_DOUBLE_GAP_S:
                            first_clap_time = None
                            last_logged_double = now
                            if not welcome_sequence_done:
                                welcome_sequence_done = True
                                log.info(
                                    "Double clap detected (gap=%.3fs, rms=%.5f, "
                                    "noise_floor=%.5f, threshold=%.5f) — running welcome once",
                                    gap,
                                    level,
                                    noise_floor,
                                    threshold,
                                )
                                threading.Thread(
                                    target=run_double_clap_actions,
                                    args=(input_idx,),
                                    daemon=True,
                                ).start()
                        else:
                            first_clap_time = now

    except KeyboardInterrupt:
        log.info("Stopped.")
        return 0
    except sd.PortAudioError as e:
        log.error("Audio error: %s", e)
        log.error("If PortAudio fails, install/repair drivers or try another SAMPLE_RATE.")
        return 1

    return 0

def main() -> int:
    blocksize = block_samples()

    try:
        import jarvis_overlay

        jarvis_overlay.start()
        jarvis_overlay.set_message_handler(handle_command)
        log.info("Bandeja del sistema lista — click para opciones, o el atajo de texto para el chat.")
    except ImportError:
        log.warning(
            "No se encontró jarvis_overlay.py o falta PySide6 — sigue funcionando "
            "todo, solo que sin bandeja ni círculo visual."
        )

    if JARVIS_VOICE_COMMAND_MODE == "mcp_agent":
        try:
            from nemotron_mcp_agent import ensure_started as _ensure_mcp_started

            _ensure_mcp_started(wait=False)
            log.info(
                "Arrancando el servidor MCP (windows-mcp) en paralelo — puede tardar "
                "20-40s la primera vez; el primer comando espera a que esté listo."
            )
        except ImportError as e:
            log.warning(
                "No se pudo pre-arrancar el servidor MCP (¿nemotron_mcp_agent.py al "
                "lado de jarvis.py?): %s",
                e,
            )

    log.info("Trigger mode: %s (JARVIS_TRIGGER_MODE)", JARVIS_TRIGGER_MODE)
    if JARVIS_TRIGGER_MODE == "hotkey":
        log.info(
            "Hotkeys: %s = voz (JARVIS_HOTKEY), %s = caja de texto (JARVIS_TEXT_HOTKEY)",
            JARVIS_HOTKEY,
            JARVIS_TEXT_HOTKEY,
        )
    elif JARVIS_TRIGGER_MODE == "wakeword":
        log.info(
            "Wakeword: %r. Después de la wakeword escucha hasta %.0fs (corta con "
            "%.1fs de silencio). Decir 'nada'/'cancelar' etc. cancela con un preset, "
            "sin gastar ninguna API de IA. %s también disponible para escribir.",
            WAKEWORD_NAME,
            WAKEWORD_COMMAND_MAX_S,
            WAKEWORD_SILENCE_HANG_S,
            JARVIS_TEXT_HOTKEY,
        )
    if SONG_URI.strip():
        log.info("Trigger opens this track: %s", SONG_URI.strip())
    else:
        log.info("SONG_URI is empty — set it to play one song on each trigger.")
    if FOCUS_EXISTING_CURSOR_ON_DOUBLE_CLAP:
        log.info(
            "Trigger will foreground an existing Cursor window (Windows API); "
            "falls back to launching Cursor if none is running."
        )
    if OPEN_NEW_CURSOR_ON_DOUBLE_CLAP:
        log.info("Trigger will also open a new Cursor window (-n).")
    if CURSOR_OPEN_FULLSCREEN and sys.platform == "win32":
        log.info("Cursor will be sent F11 for fullscreen after focus/launch.")
    if OPEN_CLAUDE_CODE_IN_CHROME:
        cu = (os.environ.get("CLAUDE_CODE_URL") or "https://claude.ai/new").strip()
        log.info(
            "After Spotify, open Claude in Chrome%s on monitor %d: %s",
            " fullscreen" if OPEN_CHROME_FULLSCREEN else "",
            CLAUDE_CHROME_MONITOR,
            cu,
        )
    if OPEN_BINANCE_BTC_IN_CHROME:
        bu = (
            os.environ.get("BINANCE_BTC_URL")
            or "https://www.binance.com/en/trade/BTC_USDT"
        ).strip()
        log.info(
            "After Spotify, open Binance BTC in Chrome%s on monitor %d: %s",
            " fullscreen" if OPEN_CHROME_FULLSCREEN else "",
            BINANCE_CHROME_MONITOR,
            bu,
        )
    if JARVIS_WELCOME_ENABLED:
        ev, em, ef, er = elevenlabs_env_config()
        welcome_desc = (
            "Nemotron-generated line" if JARVIS_AI_DYNAMIC_WELCOME else repr(JARVIS_WELCOME_PHRASE.strip())
        )
        log.info(
            "After song + %.2fs: %s (ElevenLabs voice=%s, model=%s, format=%s, pcm_rate=%d)",
            JARVIS_AFTER_SONG_DELAY_S,
            welcome_desc,
            ev or "(unset)",
            em,
            ef,
            er,
        )
    if JARVIS_AI_ENABLED:
        has_key = bool((os.environ.get("NVIDIA_API_KEY") or "").strip())
        log.info(
            "Nemotron 3 Ultra: model=%s base_url=%s api_key=%s",
            NVIDIA_MODEL,
            NVIDIA_BASE_URL,
            "set" if has_key else "MISSING (set NVIDIA_API_KEY)",
        )
        if JARVIS_VOICE_COMMANDS_ENABLED:
            if JARVIS_VOICE_COMMAND_MODE == "mcp_agent":
                log.info(
                    "Trigger will record %.1fs and hand it to Nemotron as an MCP agent "
                    "(windows-mcp tools, open-ended). Set JARVIS_VOICE_COMMAND_MODE=fixed "
                    "to go back to the 5 fixed actions.",
                    VOICE_COMMAND_RECORD_S,
                )
                try:
                    import llm_health

                    llm_health.run_startup_check()
                except ImportError as e:
                    log.warning(
                        "No se pudo correr el chequeo de salud de proveedores "
                        "(¿llm_health.py/llm_providers.py están al lado de jarvis.py?): %s",
                        e,
                    )
            else:
                log.info(
                    "Trigger will record %.1fs and ask Nemotron to route it to one of: %s",
                    VOICE_COMMAND_RECORD_S,
                    ", ".join(ACTIONS.keys()),
                )

    input_idx = _choose_input_device(blocksize)

    if JARVIS_TRIGGER_MODE == "hotkey":
        return _run_hotkey_trigger(input_idx)
    if JARVIS_TRIGGER_MODE == "text":
        return _run_text_trigger()
    if JARVIS_TRIGGER_MODE == "wakeword":
        return _run_wakeword_trigger(input_idx)
    return _run_clap_trigger(input_idx, blocksize)

if __name__ == "__main__":
    sys.exit(main())