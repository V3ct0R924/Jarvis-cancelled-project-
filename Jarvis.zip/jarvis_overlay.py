#!/usr/bin/env python3
"""
jarvis_overlay.py — the one and only Qt app for Jarvis: the pulsing circle overlay,
a system tray icon, and a settings window (API keys/models + trigger/wakeword config).

Everything lives in ONE QApplication running in its own background thread (Qt does
not allow more than one QApplication per process) — started once via start();
show()/hide() (for the circle) and open_settings() are then safe to call from ANY
thread, via Qt signals (auto-queued onto the GUI thread by Qt when the caller is on a
different one).

Settings are read from and written to the .env file next to this script (same one
jarvis.py loads). Saving updates os.environ immediately for values that jarvis.py's
other modules read fresh on every call (all the *_API_KEY / *_MODEL / JARVIS_LLM_PROVIDER
ones, since llm_providers.py reads os.environ live) — those apply right away, no
restart needed. Anything jarvis.py itself only reads once at import time (trigger mode,
hotkeys, wakeword settings) needs a restart of jarvis.py to take effect; the settings
window says so.

Needs: pip install PySide6
"""

from __future__ import annotations

import math
import os
import sys
import threading
from pathlib import Path

_app_thread: threading.Thread | None = None
_controller = None
_ready = threading.Event()
_on_message_callback = None

_SIZE = 90
_MARGIN_X = 24
_COLOR_RGB = (77, 163, 255)

ENV_PATH = Path(__file__).resolve().parent / ".env"

PROVIDER_FIELDS = [
    ("NVIDIA (Nemotron)", "NVIDIA_API_KEY", "NVIDIA_MODEL", "nvidia/nemotron-3-ultra-550b-a55b"),
    ("OpenAI", "OPENAI_API_KEY", "OPENAI_MODEL", "gpt-4.1"),
    ("Gemini", "GEMINI_API_KEY", "GEMINI_MODEL", "gemini-flash-latest"),
    ("Groq", "GROQ_API_KEY", "GROQ_MODEL", "openai/gpt-oss-20b"),
    ("Mistral", "MISTRAL_API_KEY", "MISTRAL_MODEL", "mistral-small-latest"),
    ("Claude", "CLAUDE_API_KEY", "CLAUDE_MODEL", "claude-sonnet-4-5"),
]

GENERAL_FIELDS = [
    ("JARVIS_TRIGGER_MODE", "combo", ["wakeword", "hotkey", "text", "clap"], "wakeword"),
    ("JARVIS_HOTKEY", "text", None, "ctrl+alt+space"),
    ("JARVIS_TEXT_HOTKEY", "text", None, "ctrl+alt+t"),
    ("JARVIS_WAKEWORD", "text", None, "hey_jarvis"),
    ("JARVIS_WAKEWORD_THRESHOLD", "text", None, "0.5"),
    ("JARVIS_WAKEWORD_MAX_S", "text", None, "60"),
    ("JARVIS_WAKEWORD_SILENCE_HANG_S", "text", None, "1.5"),
    ("JARVIS_VOICE_COMMAND_MODE", "combo", ["mcp_agent", "fixed"], "mcp_agent"),
    ("ELEVENLABS_VOICE_ID", "text", None, ""),
    ("ELEVENLABS_MODEL_ID", "text", None, "eleven_multilingual_v2"),
]


def _read_env_lines() -> list[str]:
    if ENV_PATH.is_file():
        return ENV_PATH.read_text(encoding="utf-8").splitlines()
    return []


def env_set_many(values: dict[str, str]) -> None:
    lines = _read_env_lines()
    seen: set[str] = set()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key = stripped.split("=", 1)[0].strip()
        if key in values:
            lines[i] = f"{key}={values[key]}"
            seen.add(key)
    for key, val in values.items():
        if key not in seen:
            lines.append(f"{key}={val}")
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for key, val in values.items():
        os.environ[key] = val


def _run() -> None:
    from PySide6.QtCore import QObject, QPointF, Qt, QTimer, Signal
    from PySide6.QtGui import QAction, QColor, QIcon, QPainter, QPixmap
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMenu,
        QMessageBox,
        QPushButton,
        QSystemTrayIcon,
        QTabWidget,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )

    class ChatWindow(QWidget):
        def __init__(self) -> None:
            super().__init__()
            self.setWindowTitle("Jarvis — Chat")
            self.resize(420, 560)

            self.log = QTextEdit()
            self.log.setReadOnly(True)
            self.log.setStyleSheet(
                "QTextEdit { background: #1e1e1e; color: #ddd; border: none; "
                "font-size: 13px; padding: 8px; }"
            )

            self.input = QLineEdit()
            self.input.setPlaceholderText("Escribí un mensaje para Jarvis...")
            self.input.returnPressed.connect(self._on_send)

            self.send_btn = QPushButton("Enviar")
            self.send_btn.clicked.connect(self._on_send)

            input_row = QHBoxLayout()
            input_row.addWidget(self.input)
            input_row.addWidget(self.send_btn)

            layout = QVBoxLayout(self)
            layout.addWidget(self.log)
            layout.addLayout(input_row)

        def _on_send(self) -> None:
            text = self.input.text().strip()
            if not text:
                return
            self.input.clear()
            self.append("Vos", text)
            self._set_waiting(True)
            if _on_message_callback is not None:
                threading.Thread(target=_on_message_callback, args=(text,), daemon=True).start()
            else:
                self.append("Jarvis", "(no hay nada conectado para procesar mensajes todavía)")
                self._set_waiting(False)

        def _set_waiting(self, waiting: bool) -> None:
            self.input.setEnabled(not waiting)
            self.send_btn.setEnabled(not waiting)
            self.send_btn.setText("..." if waiting else "Enviar")

        def append(self, role: str, text: str) -> None:
            color = "#4da3ff" if role.lower() == "vos" else "#8fce9c"
            safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            self.log.append(f'<b style="color:{color}">{role}:</b> {safe}')
            if role.lower() != "vos":
                self._set_waiting(False)

        def closeEvent(self, event) -> None:
            event.ignore()
            self.hide()

    class Overlay(QWidget):
        def __init__(self) -> None:
            super().__init__()
            self.setWindowFlags(
                Qt.FramelessWindowHint
                | Qt.WindowStaysOnTopHint
                | Qt.Tool
                | Qt.WindowTransparentForInput
            )
            self.setAttribute(Qt.WA_TranslucentBackground)
            self.setAttribute(Qt.WA_TransparentForMouseEvents)
            self.setAttribute(Qt.WA_ShowWithoutActivating)
            self.resize(_SIZE, _SIZE)
            screen = QApplication.primaryScreen().geometry()
            self.move(_MARGIN_X, screen.height() // 2 - _SIZE // 2)
            self._t = 0.0
            self._timer = QTimer(self)
            self._timer.timeout.connect(self._tick)
            self.hide()

        def _tick(self) -> None:
            self._t += 0.25
            self.update()

        def paintEvent(self, _event) -> None:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            pulse = (math.sin(self._t) + 1) / 2
            r = _SIZE * 0.28 + _SIZE * 0.14 * pulse
            cx = cy = _SIZE / 2
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(*_COLOR_RGB))
            painter.drawEllipse(QPointF(cx, cy), r, r)

        def start_pulse(self) -> None:
            self._t = 0.0
            self._timer.start(50)
            self.show()

        def stop_pulse(self) -> None:
            self._timer.stop()
            self.hide()

    def _make_icon():
        pix = QPixmap(64, 64)
        pix.fill(Qt.transparent)
        painter = QPainter(pix)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(*_COLOR_RGB))
        painter.drawEllipse(QPointF(32, 32), 26, 26)
        painter.end()
        return QIcon(pix)

    class SettingsWindow(QWidget):
        def __init__(self) -> None:
            super().__init__()
            self.setWindowTitle("Jarvis — Opciones")
            self.resize(480, 420)
            self._fields: dict[str, QWidget] = {}

            tabs = QTabWidget()
            tabs.addTab(self._build_apis_tab(), "APIs")
            tabs.addTab(self._build_general_tab(), "General / Wakeword")

            self._status = QLabel("")
            self._status.setStyleSheet("color: #888;")

            save_btn = QPushButton("Guardar")
            save_btn.clicked.connect(self._save)
            close_btn = QPushButton("Cerrar")
            close_btn.clicked.connect(self.hide)

            btn_row = QHBoxLayout()
            btn_row.addWidget(self._status)
            btn_row.addStretch(1)
            btn_row.addWidget(save_btn)
            btn_row.addWidget(close_btn)

            layout = QVBoxLayout(self)
            layout.addWidget(tabs)
            layout.addLayout(btn_row)

        def _build_apis_tab(self) -> QWidget:
            w = QWidget()
            form = QFormLayout(w)

            provider_combo = QComboBox()
            provider_combo.addItems(["auto", "nvidia", "openai", "gemini", "groq", "mistral", "claude"])
            current = os.environ.get("JARVIS_LLM_PROVIDER", "auto").strip().lower()
            if current in [provider_combo.itemText(i) for i in range(provider_combo.count())]:
                provider_combo.setCurrentText(current)
            self._fields["JARVIS_LLM_PROVIDER"] = provider_combo
            form.addRow("Proveedor (auto = router elige):", provider_combo)

            for label, key_env, model_env, default_model in PROVIDER_FIELDS:
                key_edit = QLineEdit(os.environ.get(key_env, ""))
                key_edit.setEchoMode(QLineEdit.Password)
                toggle = QPushButton("👁")
                toggle.setFixedWidth(28)
                toggle.setCheckable(True)
                toggle.toggled.connect(
                    lambda checked, e=key_edit: e.setEchoMode(
                        QLineEdit.Normal if checked else QLineEdit.Password
                    )
                )
                key_row = QHBoxLayout()
                key_row.addWidget(key_edit)
                key_row.addWidget(toggle)
                key_row_w = QWidget()
                key_row_w.setLayout(key_row)
                self._fields[key_env] = key_edit
                form.addRow(f"{label} — API key:", key_row_w)

                model_edit = QLineEdit(os.environ.get(model_env, ""))
                model_edit.setPlaceholderText(default_model)
                self._fields[model_env] = model_edit
                form.addRow(f"{label} — modelo:", model_edit)

            return w

        def _build_general_tab(self) -> QWidget:
            w = QWidget()
            form = QFormLayout(w)
            note = QLabel(
                "Estos cambios necesitan reiniciar jarvis.py para aplicarse\n"
                "(se leen una sola vez al arrancar)."
            )
            note.setStyleSheet("color: #a86;")
            form.addRow(note)

            for key, kind, options, default in GENERAL_FIELDS:
                current = os.environ.get(key, default)
                if kind == "combo":
                    combo = QComboBox()
                    combo.addItems(options)
                    if current in options:
                        combo.setCurrentText(current)
                    self._fields[key] = combo
                    form.addRow(f"{key}:", combo)
                else:
                    edit = QLineEdit(current)
                    self._fields[key] = edit
                    form.addRow(f"{key}:", edit)

            return w

        def _save(self) -> None:
            values: dict[str, str] = {}
            for key, widget in self._fields.items():
                if isinstance(widget, QComboBox):
                    values[key] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    values[key] = widget.text()
            try:
                env_set_many(values)
                self._status.setText("Guardado ✓")
            except OSError as e:
                QMessageBox.warning(self, "Error al guardar", str(e))
                return

        def closeEvent(self, event) -> None:
            event.ignore()
            self.hide()

    class Controller(QObject):
        show_requested = Signal()
        hide_requested = Signal()
        open_settings_requested = Signal()
        open_chat_requested = Signal()
        append_chat_requested = Signal(str, str)

        def __init__(self, overlay: Overlay, settings: SettingsWindow, chat: ChatWindow) -> None:
            super().__init__()
            self.overlay = overlay
            self.settings = settings
            self.chat = chat
            self.show_requested.connect(overlay.start_pulse)
            self.hide_requested.connect(overlay.stop_pulse)
            self.open_settings_requested.connect(self._open_settings)
            self.open_chat_requested.connect(self._open_chat)
            self.append_chat_requested.connect(chat.append)

        def _open_settings(self) -> None:
            self.settings.show()
            self.settings.raise_()
            self.settings.activateWindow()

        def _open_chat(self) -> None:
            self.chat.show()
            self.chat.raise_()
            self.chat.activateWindow()
            self.chat.input.setFocus()

    app = QApplication.instance() or QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    overlay = Overlay()
    settings = SettingsWindow()
    chat = ChatWindow()
    global _controller
    _controller = Controller(overlay, settings, chat)

    icon = _make_icon()
    tray = QSystemTrayIcon(icon)
    tray.setToolTip("Jarvis")
    menu = QMenu()
    open_action = QAction("Abrir opciones")
    open_action.triggered.connect(_controller.open_settings_requested.emit)
    chat_action = QAction("Abrir chat")
    chat_action.triggered.connect(_controller.open_chat_requested.emit)
    quit_action = QAction("Salir")
    quit_action.triggered.connect(lambda: os._exit(0))
    menu.addAction(chat_action)
    menu.addAction(open_action)
    menu.addSeparator()
    menu.addAction(quit_action)
    tray.setContextMenu(menu)
    tray.activated.connect(
        lambda reason: _controller.open_settings_requested.emit()
        if reason == QSystemTrayIcon.Trigger
        else None
    )
    tray.show()

    _ready.set()
    app.exec()


def start() -> None:
    """Call once, early (e.g. right at the top of main()). Safe to call more than
    once — a no-op after the first. Sets up the tray icon, the settings window, the
    chat window, and the pulsing overlay, all sharing one QApplication."""
    global _app_thread
    if _app_thread is not None:
        return
    _app_thread = threading.Thread(target=_run, daemon=True)
    _app_thread.start()
    _ready.wait(timeout=5)


def show() -> None:
    if _controller is not None:
        _controller.show_requested.emit()


def hide() -> None:
    if _controller is not None:
        _controller.hide_requested.emit()


def open_settings() -> None:
    if _controller is not None:
        _controller.open_settings_requested.emit()


def open_chat() -> None:
    if _controller is not None:
        _controller.open_chat_requested.emit()


def append_chat(role: str, text: str) -> None:
    if _controller is not None:
        _controller.append_chat_requested.emit(role, text)


def set_message_handler(fn) -> None:
    """fn(text: str) -> None. Called from a NEW background thread (never the Qt
    thread) whenever the user sends a message from the chat window — wire this to
    jarvis.py's handle_command() at startup. The handler is responsible for calling
    append_chat("Jarvis", reply) itself once it has an answer."""
    global _on_message_callback
    _on_message_callback = fn


if __name__ == "__main__":
    import time

    start()
    show()
    time.sleep(4)
    hide()
    time.sleep(3600)