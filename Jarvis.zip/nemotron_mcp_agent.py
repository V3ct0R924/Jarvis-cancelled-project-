#!/usr/bin/env python3
"""
nemotron_mcp_agent.py — Nemotron (or another configured provider) as the MCP
client/agent (not Claude Code).

Spawns `uvx windows-mcp serve` as a local MCP server, lists its tools, hands them to
the LLM as OpenAI-style function-calling tools, and runs a plain tool-call loop: the
model picks a tool + args -> we run it immediately -> feed the result back -> repeat
until it answers in plain text instead of calling another tool.

Auto-approve mode: every tool (including PowerShell, Registry, FileSystem deletes,
Process kill, mouse/keyboard) runs with no confirmation dialog and no exclusions. This
is deliberate — full hands-free voice control, no "allow this?" popups. It also means a
misheard voice command runs exactly as heard, with nothing to catch it. See the NOTE
above SAFE_TOOLS below if you ever want a partial gate back for just the destructive
tools.

Persistent MCP session: `uvx windows-mcp serve` is spawned ONCE, in a background
thread with its own asyncio event loop, at jarvis.py startup — not on every command.
That startup (subprocess spawn + MCP handshake) can easily take 20-40s on its own;
paying it once instead of on every single request is most of what makes commands feel
instant after the first one. See ensure_started()/run_agent_sync() below.

Needs: pip install mcp requests
Env:   see llm_providers.py's docstring for the provider(s) you're using

CLI test, no jarvis.py needed:
    python nemotron_mcp_agent.py "abrí el bloc de notas y escribí hola mundo"
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import logging
import os
import sys
import threading
import time
from pathlib import Path

from dotenv import load_dotenv
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

import jarvis_memory
import llm_providers
import printing_tools
import skills_tools
import vscode_tools

LOCAL_TOOL_MODULES = [vscode_tools, skills_tools, printing_tools]

load_dotenv(Path(__file__).resolve().parent / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("nemotron_mcp_agent")

MAX_AGENT_STEPS = int(os.environ.get("MCP_AGENT_MAX_STEPS", "15"))
CONFIRM_TIMEOUT_S = float(os.environ.get("MCP_AGENT_CONFIRM_TIMEOUT_S", "30"))

# --- Persistent MCP session/event loop --------------------------------------------
# Everything that touches the MCP session — opening it AND every later tool call —
# has to run inside the SAME asyncio Task, not just the same loop/thread: the `mcp`
# SDK's transport is built on anyio, whose cancel scopes are tied to the task that
# entered them. A command queue processed by one long-lived task (_server_task)
# keeps every session touch on that one task, instead of run_coroutine_threadsafe
# spawning a fresh task per command (which is what broke it the first way).
_persistent_loop: asyncio.AbstractEventLoop | None = None
_persistent_thread: threading.Thread | None = None
_command_queue: asyncio.Queue | None = None
_session_tools_schema: list[dict] | None = None
_session_ready = threading.Event()
_session_error: Exception | None = None


async def _server_task() -> None:
    global _session_tools_schema, _session_error, _command_queue
    _command_queue = asyncio.Queue()
    try:
        params = StdioServerParameters(command="uvx", args=["windows-mcp", "serve"])
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                listed = await session.list_tools()
                local_schemas = [s for mod in LOCAL_TOOL_MODULES for s in mod.schemas()]
                _session_tools_schema = _mcp_tools_to_openai_schema(listed.tools) + local_schemas
                log.info(
                    "Servidor MCP listo. Tools disponibles: %s",
                    [t["function"]["name"] for t in _session_tools_schema],
                )
                _session_ready.set()

                while True:
                    transcript, fut = await _command_queue.get()
                    try:
                        result = await _run_agent_impl(transcript, session, _session_tools_schema)
                        if not fut.cancelled():
                            fut.set_result(result)
                    except Exception as e:
                        if not fut.cancelled():
                            fut.set_exception(e)
    except Exception as e:
        _session_error = e
        log.error("No se pudo iniciar el servidor MCP (windows-mcp): %s", e)
        _session_ready.set()


def _loop_main() -> None:
    global _persistent_loop
    loop = asyncio.new_event_loop()
    _persistent_loop = loop
    asyncio.set_event_loop(loop)
    loop.create_task(_server_task())
    loop.run_forever()


def ensure_started(wait: bool = True, timeout: float = 60.0) -> None:
    """Starts the persistent MCP server + event-loop thread (no-op if already
    started). With wait=True, blocks until the session is ready (or timeout/error) —
    use wait=False at jarvis.py's own startup to kick this off in the background
    without delaying the rest of its init, and wait=True (the default) from
    run_agent_sync, where you actually need the session before proceeding."""
    global _persistent_thread
    if _persistent_thread is None:
        _persistent_thread = threading.Thread(target=_loop_main, daemon=True)
        _persistent_thread.start()
    if wait:
        if not _session_ready.wait(timeout=timeout):
            log.warning("El servidor MCP no terminó de iniciar en %.0fs.", timeout)

# --- Task classifier: local, instant, no API call --------------------------------
# Purposely simple and cheap to run for every single request. It only needs to be
# right most of the time — a "simple" task routed to a fast small model still works,
# it's just not the absolute best possible answer; a "complex" one routed to the
# quality tier costs a bit more latency but that's the right trade for those.
_COMPLEX_HINTS = (
    "código", "codigo", "script", "función", "funcion", "programa", "programá",
    "programa", "debug", "bug", "refactor", "python", "powershell", "clase",
    "algoritmo", "explica", "explicá", "explicame", "analiza", "analizá", "compará",
    "compara", "planifica", "planificá", "diseña", "diseñá", "investiga", "investigá",
    "resumí", "resumi", "resume", "por qué", "por que", "cómo funciona", "como funciona",
    "vscode", "vs code", "visual studio code", "archivo.py", "repositorio", "repo",
    "powerpoint", "presentación", "presentacion", "diapositiva", "excel", "planilla",
    "hoja de cálculo", "hoja de calculo", "word", "documento", "pdf",
    "impresión 3d", "impresion 3d", "filamento", "laminar", "slicer", "gcode",
    "g-code", "stl", "cotización", "cotizacion", "presupuesto",
)


def classify_task(transcript: str) -> str:
    """'complex' or 'simple' — see llm_providers.QUALITY_RANK / FAST_RANK."""
    text = (transcript or "").strip().lower()
    if not text:
        return "simple"
    if any(hint in text for hint in _COMPLEX_HINTS):
        return "complex"
    word_count = len(text.split())
    if word_count > 28:
        return "complex"
    return "simple"



# NOTE: full auto-approve mode. These sets and confirm() are kept in the file, unused,
# in case you ever want a partial gate again (e.g. only for FileSystem/Process/Registry/
# PowerShell) — see the note in run_agent()'s tool-call loop for where to plug it back in.
SAFE_TOOLS = {
    "Screenshot", "Snapshot", "DisplayInventory", "Wait", "WaitFor", "Scrape",
    "Notification",
}

GEMINI_ONE_SHOT_REMINDER_TEXT = (
    "IMPORTANT, Gemini-specific: calling your API for tool-calling turns in quick "
    "succession triggers rate limiting on this account, so you get EXACTLY ONE "
    "turn for this entire task — there will be no follow-up call to you, ever, "
    "once this response is sent. Return ALL the tool calls needed to fully "
    "complete the task in THIS single response, as multiple parallel tool calls "
    "if needed. If you would normally check something first (a Screenshot/Snapshot) "
    "before deciding the rest, make your best judgment call now instead — do not "
    "save any step for later, there is no later."
)


def _with_gemini_reminder(messages: list[dict]) -> list[dict]:
    """Copy of `messages` with the one-shot reminder merged into the FIRST system
    message. It used to be appended as an extra system message at the END of the
    conversation, and Gemini's OpenAI-compat endpoint answered those calls with an
    empty response (no text, no tool calls) — system instructions belong up front."""
    if messages and messages[0].get("role") == "system":
        merged = dict(messages[0])
        merged["content"] = f"{merged.get('content', '')}\n\n{GEMINI_ONE_SHOT_REMINDER_TEXT}"
        return [merged, *messages[1:]]
    return [{"role": "system", "content": GEMINI_ONE_SHOT_REMINDER_TEXT}, *messages]


def _win_known_folder(guid_str: str) -> str | None:
    """Real path of a Windows known folder (Desktop/Documents/Downloads), which is
    NOT always C:\\Users\\<name>\\Desktop — OneDrive commonly redirects it."""
    import ctypes
    import uuid
    from ctypes import wintypes

    class _GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", wintypes.DWORD),
            ("Data2", wintypes.WORD),
            ("Data3", wintypes.WORD),
            ("Data4", wintypes.BYTE * 8),
        ]

    u = uuid.UUID(guid_str)
    guid = _GUID(u.time_low, u.time_mid, u.time_hi_version, (wintypes.BYTE * 8)(*u.bytes[8:]))
    ptr = ctypes.c_void_p()
    if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(ptr)) != 0:
        return None
    try:
        return ctypes.wstring_at(ptr.value)
    finally:
        ctypes.windll.ole32.CoTaskMemFree(ptr)


def _known_folders() -> dict[str, str]:
    home = Path.home()
    folders = {
        "Home": str(home),
        "Desktop": str(home / "Desktop"),
        "Documents": str(home / "Documents"),
        "Downloads": str(home / "Downloads"),
    }
    if sys.platform == "win32":
        guids = {
            "Desktop": "B4BFCC3A-DB2C-424C-B029-7FE99A87C641",
            "Documents": "FDD39AD0-238F-46AF-ADB4-6C85480369C7",
            "Downloads": "374DE290-123F-4565-9164-39C4925E467B",
        }
        for name, guid in guids.items():
            try:
                real = _win_known_folder(guid)
            except Exception:
                real = None
            if real:
                folders[name] = real
    return folders


_FOLDERS = _known_folders()

JARVIS_LANGUAGE_NAME = os.environ.get("JARVIS_LANGUAGE_NAME", "Spanish (Argentina, Río de la Plata)")

SYSTEM_PROMPT = (
    f"You are Jarvis, an assistant with tool access to the user's live Windows desktop "
    "via MCP.\n\n"
    f"LANGUAGE: ALWAYS think and respond in {JARVIS_LANGUAGE_NAME} — every reply, every "
    "summary, no exceptions — regardless of what language the request happens to be "
    "phrased in, what language tool output comes back in, or what language you might "
    "default to otherwise. Never switch to English, Portuguese, or anything else.\n\n"
    "PATHS: ALWAYS use absolute paths — never relative ones like 'Test/file.py': they "
    "resolve against an unknown working directory and the file ends up somewhere the "
    "user will never find it. This user's real folders — Desktop (\"el escritorio\"): "
    f"{_FOLDERS['Desktop']} | Documents: {_FOLDERS['Documents']} | Downloads: "
    f"{_FOLDERS['Downloads']} | Home: {_FOLDERS['Home']}. If a folder has to exist "
    "before you write into it, create it first (PowerShell: New-Item -ItemType "
    "Directory -Force -Path <abs path>).\n\n"
    "COMPLETENESS: if the request names several things to create or do (e.g. two "
    "files, three apps), do ALL of them before answering — don't stop after the first "
    "one. For file creation, verify at the end (list the folder) and only then report "
    "what exists.\n\n"
    "STRONGLY PREFER PowerShell (or App with mode=launch_executable and cmd.exe) for "
    "anything that a single shell command can do in one shot: opening a URL, opening an "
    "app, opening a URL in a specific browser, searching something, killing a process, "
    "reading/writing/moving/deleting a file. One example that always works: "
    "PowerShell with command=Start-Process 'https://example.com' opens the default "
    "browser at that URL in a single call — do that instead of launching a browser and "
    "then clicking the address bar and typing the URL. To force a specific browser: "
    "Start-Process 'chrome.exe' -ArgumentList 'https://example.com'.\n\n"
    "MULTIPLE INDEPENDENT ACTIONS IN ONE REQUEST: if the user asks for several separate "
    "things at once (e.g. 'abrí youtube, steam y discord'), issue ALL of the "
    "corresponding tool calls together in this same turn, as multiple tool calls in one "
    "response — do not do one, wait for the result, then ask for the next one across "
    "several turns. One exception: if a later action genuinely depends on the result of "
    "an earlier one (you need to see something first), then it's fine to sequence those "
    "specific ones — but anything independent (opening N unrelated apps/URLs) always "
    "goes out together in a single batch of tool calls.\n\n"
    "WINDOW FOCUS: by default, open things WITHOUT stealing focus or covering what the "
    "user is already doing — they're usually in the middle of something else. For "
    "PowerShell/Start-Process, add -WindowStyle Minimized (e.g. Start-Process "
    "'https://youtube.com' -WindowStyle Minimized) so it opens in the background. Only "
    "open something in the foreground/visible/maximized when the user's request says so "
    "explicitly (e.g. 'abrí X y mostralo', 'que se vea', 'en primer plano', 'en pantalla "
    "completa') — if they don't say anything about it, default to minimized/background, "
    "every time, for every app in the batch.\n\n"
    "CODING / VS CODE TASKS: when the user asks you to write, edit, create, or fix "
    "code, or to open a project/file in VS Code:\n"
    "  - Write the actual code with the FileSystem tool directly on disk — never by "
    "clicking into the editor and typing character by character, that's slow and "
    "error-prone.\n"
    "  - Use VSCodeOpen to open/show the project folder or a specific file to the user "
    "afterwards (reuses the current window by default). Use VSCodeOpenAt to point them "
    "at an exact line you just wrote/changed. Use VSCodeDiff to show a before/after.\n"
    "  - To build/run/test/install, use the PowerShell tool in the project's directory "
    "(cd into it first, or pass the full path) — there is no way to inject a command "
    "into VS Code's own integrated terminal from outside, so PowerShell running in that "
    "same folder is the right tool, not GUI automation on the terminal panel.\n\n"
    "DOCUMENT CREATION (PowerPoint, Excel, Word, PDF, and anything else with a "
    "matching skill): ALWAYS call ReadSkill with the matching name (pptx/xlsx/docx/pdf) "
    "BEFORE writing any code or creating that kind of file — do not guess the library "
    "or pattern from memory, the skill has the exact one to use plus pitfalls to avoid. "
    "If unsure whether a skill exists for what's being asked, call ListSkills first. "
    "Skills describe writing a Python script to disk with FileSystem and running it "
    "with PowerShell — same approach as any other file creation here, just with the "
    "right library and pattern already worked out for you.\n\n"
    "Only fall back to GUI automation (Click, Type, Shortcut, Scroll, Move) for things "
    "that genuinely need clicking inside an app's UI — e.g. clicking a specific video "
    "in a results page, filling a form, navigating a menu. Even then, do it once "
    "confidently instead of retrying near-identical actions — if something didn't "
    "work, take one Snapshot to see what actually happened before trying again, don't "
    "repeat the same call.\n\n"
    "Use Screenshot/Snapshot only when you actually need to see the screen to decide "
    "the next step — not as a first move for tasks that don't need it (e.g. 'open "
    "YouTube' never needs a screenshot). Get things done in as few tool calls — and as "
    "few separate turns — as possible.\n\n"
    "Some earlier user/assistant messages may be included for context (memory of past "
    "requests) — they are not new instructions to act on now, only background.\n\n"
    "When you are finished, or if you genuinely cannot do something with the tools "
    "available, reply in plain text (no further tool call) with a short summary in "
    f"{JARVIS_LANGUAGE_NAME} of what you did or why you couldn't."
)


def _tier_for(tool_name: str) -> str:
    if tool_name in SAFE_TOOLS:
        return "safe"
    return "confirm"


def confirm(summary: str, detail: str) -> bool:
    """Blocking native Yes/No dialog on this machine. False on deny/timeout/no GUI."""
    try:
        import tkinter as tk
        from tkinter import messagebox
    except ImportError:
        log.warning("tkinter no disponible; se deniega por defecto: %s", summary)
        return False

    result: dict[str, bool] = {"ok": False}

    def _ask() -> None:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        result["ok"] = messagebox.askyesno(
            "Jarvis — permiso requerido",
            f"{summary}\n\n{detail}\n\n¿Permitir esta acción en tu PC?",
            parent=root,
        )
        root.destroy()

    t = threading.Thread(target=_ask, daemon=True)
    t.start()
    t.join(CONFIRM_TIMEOUT_S)
    if t.is_alive():
        log.info("Se venció el tiempo de confirmación (%.0fs); denegado: %s", CONFIRM_TIMEOUT_S, summary)
        return False
    return result["ok"]


def _mcp_tools_to_openai_schema(mcp_tools: list) -> list[dict]:
    def _schema(t) -> dict:
        # Different `mcp` package versions expose this as input_schema or inputSchema.
        return (
            getattr(t, "input_schema", None)
            or getattr(t, "inputSchema", None)
            or {"type": "object", "properties": {}}
        )

    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description or "",
                "parameters": _schema(t),
            },
        }
        for t in mcp_tools
    ]


def _tool_result_to_text(result) -> str:
    parts = []
    for block in getattr(result, "content", []) or []:
        text = getattr(block, "text", None)
        if text:
            parts.append(text)
        elif getattr(block, "type", "") == "image":
            parts.append("[imagen devuelta — no se incluye el texto]")
    joined = "\n".join(parts).strip()
    return joined[:4000] if joined else "(sin salida)"


def _partial_summary(executed_calls: list[dict]) -> str:
    n = len(executed_calls)
    return (
        f"Alcancé a ejecutar {n} acción{'es' if n != 1 else ''}, pero no pude "
        "confirmar que la tarea haya terminado del todo. Revisá el resultado."
    )


def _local_module_for(name: str):
    for mod in LOCAL_TOOL_MODULES:
        if name in mod.TOOLS:
            return mod
    return None


async def _run_agent_impl(transcript: str, session: ClientSession, tools_schema: list[dict]) -> str:
    """One task's worth of work. Called only from inside _server_task()'s loop, on
    the same asyncio Task that owns `session` — never scheduled as a separate task,
    that's exactly what broke the MCP transport's cancel scopes before. Loads/saves
    the SQLite turn memory around the run, and checks/fills the recipe cache so a
    repeated request skips the LLM entirely."""
    final_text = "Se alcanzó el máximo de pasos sin que el agente terminara la tarea."
    executed_calls: list[dict] = []

    cached = jarvis_memory.find_recipe(transcript)
    if cached:
        log.info(
            "Receta en caché para %r (%d tool call(s)) — sin llamar al modelo.",
            transcript,
            len(cached["tool_calls"]),
        )
        for call in cached["tool_calls"]:
            log.info("Repitiendo tool %s(%s)", call["name"], call["args"])
            try:
                local_mod = _local_module_for(call["name"])
                if local_mod:
                    local_mod.call(call["name"], call["args"])
                else:
                    await session.call_tool(call["name"], call["args"])
            except Exception as e:
                log.warning(
                    "Falló %s al repetir la receta (%s) — se sigue con el resto.",
                    call["name"],
                    e,
                )
        jarvis_memory.save_turn(transcript, cached["final_text"])
        return cached["final_text"]

    complexity = classify_task(transcript)
    log.info("Tarea clasificada como '%s'.", complexity)

    messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(jarvis_memory.load_recent_as_messages())
    messages.append({"role": "user", "content": transcript})

    empty_response_providers: set[str] = set()
    completed = False
    for step in range(MAX_AGENT_STEPS):
        # Gemini requires a thought_signature on any prior functionCall part in
        # history, which we deliberately strip for cross-provider portability —
        # so it can only be picked for the FIRST call of a task, never to
        # continue one that already made a tool call (it would just fail the
        # same way every time, wasting a health-cooldown slot on a non-issue).
        has_prior_tool_call = any(
            m.get("role") == "assistant" and m.get("tool_calls") for m in messages
        )
        exclude = set(empty_response_providers)
        if has_prior_tool_call:
            exclude.add("gemini")
        exclude = exclude or None

        # If Gemini is about to be the one answering, tell it up front that this
        # is its only turn — pushes it to batch every needed action into this
        # one response instead of planning a follow-up call it will never get.
        peeked = llm_providers.peek_provider(complexity, exclude=exclude)
        call_messages = _with_gemini_reminder(messages) if peeked == "gemini" else messages

        try:
            msg, provider_used = llm_providers.chat_step_with_fallback(
                call_messages, tools_schema, complexity=complexity, exclude=exclude
            )
        except Exception as e:
            if not executed_calls:
                raise
            # Some work already ran; better to say so than to throw it all away.
            log.warning("Ningún proveedor pudo continuar la tarea: %s", e)
            final_text = _partial_summary(executed_calls)
            break
        if step == 0:
            log.info("Proveedor elegido: %s", provider_used)
        tool_calls = msg.get("tool_calls") or []
        if not tool_calls:
            content = (msg.get("content") or "").strip()
            if not content:
                # NEITHER text NOR a tool call isn't an answer, it's a failure —
                # whether or not earlier steps already ran. Accepting it as "the
                # final reply" is how a half-finished task (one file of two) used to
                # get reported as done. Retry with the next-best provider, which sees
                # the whole history including any tool results so far.
                if provider_used in empty_response_providers:
                    # A pinned provider ignores `exclude`; don't loop on it forever.
                    final_text = (
                        _partial_summary(executed_calls)
                        if executed_calls
                        else "El modelo no me devolvió ninguna respuesta."
                    )
                    break
                log.warning(
                    "%s no devolvió nada útil (sin texto ni tool calls) — probando "
                    "otro proveedor.",
                    provider_used,
                )
                empty_response_providers.add(provider_used)
                continue
            final_text = content
            completed = True
            break

        # Strip provider-specific extra fields (e.g. NVIDIA's reasoning_content)
        # before this goes into shared history — otherwise the next provider
        # the router picks can reject the message outright for containing a
        # field its schema doesn't recognize.
        messages.append(
            {
                "role": "assistant",
                "content": msg.get("content"),
                "tool_calls": [
                    {
                        "id": tc.get("id"),
                        "type": tc.get("type", "function"),
                        "function": {
                            "name": tc["function"]["name"],
                            "arguments": tc["function"].get("arguments", "{}"),
                        },
                    }
                    for tc in tool_calls
                ],
            }
        )
        for tc in tool_calls:
            name = tc["function"]["name"]
            try:
                args = json.loads(tc["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                args = {}

            # No confirmation gate — every tool runs immediately. See the NOTE
            # above SAFE_TOOLS if you ever want a partial gate back.
            log.info("Llamando tool %s(%s)", name, args)
            try:
                local_mod = _local_module_for(name)
                if local_mod:
                    result_text = local_mod.call(name, args)
                else:
                    result = await session.call_tool(name, args)
                    result_text = _tool_result_to_text(result)
                executed_calls.append({"name": name, "args": args})
            except Exception as e:  # MCP/tool-level errors shouldn't kill the loop
                result_text = f"Error ejecutando {name}: {e}"

            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.get("id", name),
                    "content": result_text,
                }
            )

    try:
        jarvis_memory.save_turn(transcript, final_text)
        # Only cache a recipe when the model itself said it was done. A run that ended
        # on the step limit, an empty reply or a provider failure is partial work —
        # replaying it later would repeat half a task and report it as finished.
        if executed_calls and completed:
            jarvis_memory.save_recipe(transcript, executed_calls, final_text)
    except Exception as e:
        log.warning("No se pudo guardar el turno/receta en memoria: %s", e)
    return final_text


def run_agent_sync(transcript: str, timeout: float = 120.0) -> str:
    """Call this from jarvis.py (or anywhere outside the persistent loop's own
    thread) — enqueues the request for _server_task() to process on its own task
    (see the note above _persistent_loop for why it has to be a queue and not a
    fresh task per call), and blocks for the result. Starts the session first if it
    hasn't been already."""
    ensure_started(wait=True, timeout=timeout)
    if _session_error is not None:
        return f"El servidor MCP no pudo iniciar: {_session_error}"
    if _persistent_loop is None or _command_queue is None:
        raise RuntimeError("El loop persistente de MCP no llegó a arrancar.")

    result_future: concurrent.futures.Future = concurrent.futures.Future()

    async def _enqueue() -> None:
        await _command_queue.put((transcript, result_future))

    asyncio.run_coroutine_threadsafe(_enqueue(), _persistent_loop)
    return result_future.result(timeout=timeout)


if __name__ == "__main__":
    text = " ".join(sys.argv[1:]) or input("Comando: ")
    start = time.time()
    print(run_agent_sync(text))
    log.info("Listo en %.1fs", time.time() - start)