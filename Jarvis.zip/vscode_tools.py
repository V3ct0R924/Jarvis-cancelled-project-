#!/usr/bin/env python3
"""
vscode_tools.py — local (no MCP round-trip) tools that let the agent control VS Code
reliably via its official `code` CLI, instead of hoping the model guesses the right
flags through a generic PowerShell/App call every time.

Each tool here runs directly in this process (subprocess.run) — nemotron_mcp_agent.py
merges these into the same tool-calling loop as the windows-mcp tools, so the model
can't tell the difference, it just sees a few more tools to pick from.

Honest limitation: there is NO official CLI way to inject a command into VS Code's
integrated terminal from outside the editor — that would need a small companion
extension (a separate project). VSCodeRunInTerminal below just explains that instead of
letting the model hallucinate a flag that doesn't exist; use the PowerShell tool to run
commands in the project folder, VS Code will pick up file changes on its own.

Needs the `code` CLI on PATH. If VS Code's own "Shell Command: Install 'code' command
in PATH" hasn't been run, these tools return a clear error saying so.
"""

from __future__ import annotations

import logging
import shutil
import subprocess

log = logging.getLogger("vscode_tools")


def _code_bin() -> str | None:
    return shutil.which("code")


def _run_code(args: list[str], timeout: float = 20.0) -> str:
    bin_path = _code_bin()
    if bin_path is None:
        return (
            "No encontré el comando `code` en el PATH. En VS Code: Ctrl+Shift+P -> "
            "'Shell Command: Install \"code\" command in PATH', después reiniciá la terminal."
        )
    try:
        result = subprocess.run(
            [bin_path, *args], capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return f"El comando code tardó más de {timeout}s."
    except OSError as e:
        return f"No se pudo ejecutar `code`: {e}"
    out = ((result.stdout or "") + (result.stderr or "")).strip()
    return out[:2000] if out else "OK"


def _looks_like_error(result: str) -> bool:
    return result.startswith(("No encontré", "No se pudo", "El comando code tardó"))


def vscode_open(path: str, new_window: bool = False, reuse_window: bool = True) -> str:
    args: list[str] = []
    if new_window:
        args.append("-n")
    elif reuse_window:
        args.append("-r")
    args.append(path)
    result = _run_code(args)
    if _looks_like_error(result):
        return result
    return f"Abrí {path} en VS Code."


def vscode_open_at(path: str, line: int, column: int = 1) -> str:
    result = _run_code(["-g", f"{path}:{line}:{column}"])
    if _looks_like_error(result):
        return result
    return f"Abrí {path} en la línea {line} en VS Code."


def vscode_diff(file1: str, file2: str) -> str:
    result = _run_code(["--diff", file1, file2])
    if _looks_like_error(result):
        return result
    return f"Mostrando diff entre {file1} y {file2} en VS Code."


def vscode_run_in_terminal_hint(command: str = "") -> str:
    return (
        "No existe una forma oficial de mandar un comando a la terminal integrada de "
        "VS Code desde afuera del editor. Usá la tool PowerShell para correrlo en la "
        "carpeta del proyecto en su lugar — VS Code va a reflejar los cambios de "
        "archivos automáticamente sin que haga falta nada más."
    )


TOOLS: dict[str, dict] = {
    "VSCodeOpen": {
        "schema": {
            "type": "function",
            "function": {
                "name": "VSCodeOpen",
                "description": (
                    "Open a folder or file in VS Code via the official CLI. Use this "
                    "to show/open a project or file to the user. Reuses the current "
                    "VS Code window by default (reuse_window=true); set new_window=true "
                    "to force a separate window instead."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Absolute path to a folder or file."},
                        "new_window": {"type": "boolean", "description": "Force a new VS Code window."},
                        "reuse_window": {"type": "boolean", "description": "Reuse the current window (default true)."},
                    },
                    "required": ["path"],
                },
            },
        },
        "func": vscode_open,
    },
    "VSCodeOpenAt": {
        "schema": {
            "type": "function",
            "function": {
                "name": "VSCodeOpenAt",
                "description": "Open a specific file in VS Code at a given line (and optional column) — e.g. to point the user at a spot you just edited.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "line": {"type": "integer"},
                        "column": {"type": "integer"},
                    },
                    "required": ["path", "line"],
                },
            },
        },
        "func": vscode_open_at,
    },
    "VSCodeDiff": {
        "schema": {
            "type": "function",
            "function": {
                "name": "VSCodeDiff",
                "description": "Show a diff between two files side by side in VS Code.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file1": {"type": "string"},
                        "file2": {"type": "string"},
                    },
                    "required": ["file1", "file2"],
                },
            },
        },
        "func": vscode_diff,
    },
    "VSCodeRunInTerminal": {
        "schema": {
            "type": "function",
            "function": {
                "name": "VSCodeRunInTerminal",
                "description": (
                    "NOT a real capability — calling this returns an explanation of why "
                    "(no official way to inject commands into VS Code's integrated "
                    "terminal) and what to use instead (the PowerShell tool). Exists so "
                    "the model gets a truthful answer instead of guessing a nonexistent "
                    "CLI flag."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {"command": {"type": "string"}},
                },
            },
        },
        "func": vscode_run_in_terminal_hint,
    },
}


def schemas() -> list[dict]:
    return [entry["schema"] for entry in TOOLS.values()]


def call(name: str, args: dict) -> str:
    entry = TOOLS.get(name)
    if entry is None:
        return f"Tool de VS Code desconocida: {name}"
    try:
        return entry["func"](**args)
    except TypeError as e:
        return f"Argumentos inválidos para {name}: {e}"
    except Exception as e:
        return f"Error en {name}: {e}"