#!/usr/bin/env python3
"""
llm_providers.py — pick which AI answers the tool-calling loop, via JARVIS_LLM_PROVIDER.

Every provider ends up returning the SAME shape (an OpenAI-style assistant message
dict: {"role": "assistant", "content": str|None, "tool_calls": [...] | None}), so
nemotron_mcp_agent.py's loop doesn't need to know which one answered.

Most of these speak the OpenAI chat-completions wire format already (NVIDIA, OpenAI,
Groq, Mistral, and Gemini via its OpenAI-compatible endpoint) — one function handles
all of them, parameterized by base_url/model/key. Claude speaks Anthropic's own Messages
API (different shape entirely: system is a top-level field, no "tool" role, tool use/
results are content blocks) — a second function translates to and from that.

Env vars (only the ones for the provider(s) you actually use are required):
  JARVIS_LLM_PROVIDER   auto (default) | nvidia | openai | gemini | groq | mistral | claude
                        "auto" hands the choice to pick_provider() below — a specific
                        name here pins every call to that one provider instead.

  NVIDIA_API_KEY,  NVIDIA_MODEL   (default nvidia/nemotron-3-ultra-550b-a55b)
  OPENAI_API_KEY,  OPENAI_MODEL   (default gpt-4.1)
  GEMINI_API_KEY,  GEMINI_MODEL   (default gemini-3-flash)
  GROQ_API_KEY,    GROQ_MODEL     (default llama-3.3-70b-versatile)
  MISTRAL_API_KEY, MISTRAL_MODEL  (default mistral-small-latest)
  CLAUDE_API_KEY,  CLAUDE_MODEL   (default claude-sonnet-4-5)
  CEREBRAS_API_KEY, CEREBRAS_MODEL     (default llama-3.3-70b) — free, no card
  OPENROUTER_API_KEY, OPENROUTER_MODEL (default meta-llama/llama-3.3-70b-instruct:free)

  NVIDIA_TIMEOUT_S / OPENAI_TIMEOUT_S / etc. — per-provider override; falls back to
  LLM_TIMEOUT_S (default 60s) if the provider-specific one isn't set.

  NEMOTRON_ENABLE_THINKING — true/false (default false). Only affects nvidia; ignored
  by every other provider (they don't share Nemotron's reasoning-toggle mechanism).

Task routing (see pick_provider / QUALITY_RANK / FAST_RANK below):
  - "complex" tasks (coding, multi-step planning, anything that benefits from deeper
    reasoning) go through QUALITY_RANK, best-first: claude, gemini, nvidia, cerebras,
    openai, groq, mistral, openrouter — per your own September 2026 ranking, with the
    two free-tier additions slotted in by rough quality.
  - "simple" tasks (open this, click that, one-shot actions — most voice commands)
    go through FAST_RANK, fastest-first: cerebras, groq, gemini, mistral, nvidia,
    openrouter — quality differences barely matter here and latency is what you feel.
  - Placeholder/unset API keys are skipped automatically (see has_real_key), so
    leaving CLAUDE_API_KEY/OPENAI_API_KEY as the sample placeholder text is fine —
    the router just falls through to the next one down the list.
  - If a provider is picked but the actual call fails (bad key, rate limit, outage),
    chat_step_with_fallback() below retries with the next candidate automatically.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass

import llm_health

log = logging.getLogger("llm_providers")

# Ranked best-first. Edit this list as your own opinion of each model changes —
# nothing else in this file needs to change when you do.
# mistral, groq and gemini were pulled out entirely (not just demoted) — mistral and
# groq failed on essentially every single real request (mistral: 429 always; groq:
# its 8000 TPM cap gets blown through in 1-2 calls against our ~29-tool prompt), and
# gemini's failures were frequent enough, between its own 503 outages and the
# thought_signature continuation issue, that it wasn't worth the retry cost either.
# Their PROVIDERS entries are still below if you ever want to bring one back — just
# add the name to one of these two lists again, nothing else needs to change.
QUALITY_RANK = ["claude", "nvidia", "cerebras", "openai", "openrouter"]
# Ranked fastest-first, for one-shot/simple commands where latency matters more than
# the small quality gap between these models. Cerebras leads: free, no card, and its
# 60k TPM cap means it doesn't choke mid-task the way Groq's 8k one does.
FAST_RANK = ["cerebras", "nvidia", "openrouter"]


@dataclass(frozen=True)
class ProviderConfig:
    name: str
    wire: str  # "openai" or "anthropic"
    base_url: str
    api_key_env: str
    model_env: str
    default_model: str
    timeout_env: str


PROVIDERS: dict[str, ProviderConfig] = {
    "nvidia": ProviderConfig(
        "nvidia", "openai",
        os.environ.get("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1"),
        "NVIDIA_API_KEY", "NVIDIA_MODEL", "nvidia/nemotron-3-ultra-550b-a55b",
        "NVIDIA_TIMEOUT_S",
    ),
    "openai": ProviderConfig(
        "openai", "openai",
        os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        "OPENAI_API_KEY", "OPENAI_MODEL", "gpt-4.1",
        "OPENAI_TIMEOUT_S",
    ),
    # Google's OpenAI-compatible endpoint — same wire format, no special-casing needed.
    "gemini": ProviderConfig(
        "gemini", "openai",
        os.environ.get(
            "GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai"
        ),
        # gemini-3-flash never GA'd as a plain name (only -preview existed briefly);
        # gemini-flash-latest is Google's own always-current alias — avoids re-breaking
        # every time they ship a new Flash generation (3.5 → 3.6 → 3.7...).
        "GEMINI_API_KEY", "GEMINI_MODEL", "gemini-flash-latest",
        "GEMINI_TIMEOUT_S",
    ),
    "groq": ProviderConfig(
        "groq", "openai",
        os.environ.get("GROQ_BASE_URL", "https://api.groq.com/openai/v1"),
        # llama-3.3-70b-versatile was decommissioned 2026-08-16; openai/gpt-oss-20b is
        # Groq's recommended fast replacement.
        "GROQ_API_KEY", "GROQ_MODEL", "openai/gpt-oss-20b",
        "GROQ_TIMEOUT_S",
    ),
    "mistral": ProviderConfig(
        "mistral", "openai",
        os.environ.get("MISTRAL_BASE_URL", "https://api.mistral.ai/v1"),
        "MISTRAL_API_KEY", "MISTRAL_MODEL", "mistral-small-latest",
        "MISTRAL_TIMEOUT_S",
    ),
    "claude": ProviderConfig(
        "claude", "anthropic",
        os.environ.get("CLAUDE_BASE_URL", "https://api.anthropic.com/v1"),
        "CLAUDE_API_KEY", "CLAUDE_MODEL", "claude-sonnet-4-5",
        "CLAUDE_TIMEOUT_S",
    ),
    # Free, no credit card. Wafer-scale hardware — very fast, and 60k TPM is far
    # more headroom than Groq's 8k, which is what kept choking mid-task above.
    "cerebras": ProviderConfig(
        "cerebras", "openai",
        os.environ.get("CEREBRAS_BASE_URL", "https://api.cerebras.ai/v1"),
        "CEREBRAS_API_KEY", "CEREBRAS_MODEL", "llama-3.3-70b",
        "CEREBRAS_TIMEOUT_S",
    ),
    # Aggregates 20+ free (":free") models from multiple providers behind one key —
    # a reasonable last resort when everything else above is down/limited at once,
    # though its own free daily cap is tight, so it belongs at the back of both ranks.
    "openrouter": ProviderConfig(
        "openrouter", "openai",
        os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
        "OPENROUTER_API_KEY", "OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free",
        "OPENROUTER_TIMEOUT_S",
    ),
}


def _timeout(cfg: ProviderConfig) -> float:
    return float(
        os.environ.get(cfg.timeout_env) or os.environ.get("LLM_TIMEOUT_S", "60")
    )


def has_real_key(name: str) -> bool:
    """False for missing keys AND for the sample placeholder text left in .env.example
    (e.g. 'your_claude_api_key_here') — so unconfigured providers are skipped cleanly
    instead of being tried and failing with a 401."""
    cfg = PROVIDERS.get(name)
    if cfg is None:
        return False
    val = (os.environ.get(cfg.api_key_env) or "").strip()
    if not val:
        return False
    low = val.lower()
    if low.startswith("your_") or low.endswith("_here") or "your_" in low:
        return False
    return True


def pick_provider(complexity: str = "simple", *, exclude: set[str] | None = None) -> str | None:
    """First provider with a real key AND not in a health cooldown, from the ranked
    list for this complexity tier. Falls back to an unhealthy-but-configured one only
    if literally nothing else is available — better a slow/failing attempt than none.
    None if nothing is configured at all."""
    exclude = exclude or set()
    rank = QUALITY_RANK if complexity == "complex" else FAST_RANK

    def _candidates(names: list[str]) -> str | None:
        healthy = [n for n in names if n not in exclude and has_real_key(n) and llm_health.is_healthy(n)]
        if healthy:
            return healthy[0]
        return None

    picked = _candidates(rank)
    if picked:
        return picked
    # Last resort within the same tier's healthy set exhausted — try the other list.
    picked = _candidates(QUALITY_RANK)
    if picked:
        return picked
    # Everything configured is currently in cooldown: pick the one configured anyway
    # rather than give up outright, since a stale cooldown estimate is still better
    # than doing nothing.
    for name in rank + QUALITY_RANK:
        if name not in exclude and has_real_key(name):
            return name
    return None


def peek_provider(complexity: str = "simple", *, exclude: set[str] | None = None) -> str | None:
    """Which provider chat_step_with_fallback would try FIRST, without calling it —
    lets the caller customize the request (e.g. a Gemini-specific prompt addendum)
    before the actual call happens. Mirrors chat_step_with_fallback's own
    pinned-vs-auto logic so the two stay in sync."""
    pinned = (os.environ.get("JARVIS_LLM_PROVIDER") or "auto").strip().lower()
    if pinned and pinned != "auto":
        return pinned if pinned in PROVIDERS else None
    return pick_provider(complexity, exclude=exclude)


def _api_key(cfg: ProviderConfig) -> str:
    key = (os.environ.get(cfg.api_key_env) or "").strip()
    if not key:
        raise RuntimeError(f"Falta {cfg.api_key_env} en el entorno/.env.")
    return key


def _model(cfg: ProviderConfig) -> str:
    return (os.environ.get(cfg.model_env) or cfg.default_model).strip()


def resolve_provider(name: str | None = None) -> ProviderConfig:
    key = (name or os.environ.get("JARVIS_LLM_PROVIDER") or "nvidia").strip().lower()
    if key not in PROVIDERS:
        raise RuntimeError(
            f"JARVIS_LLM_PROVIDER={key!r} desconocido. Opciones: {', '.join(PROVIDERS)}"
        )
    return PROVIDERS[key]


# --------------------------- OpenAI-wire providers ---------------------------

def _post_with_retry(url: str, *, headers: dict, json_body: dict, timeout: float, max_retries: int = 2):
    """POST with retries on 5xx (genuinely transient) — always logs the response body
    on error, since raise_for_status() alone hides the provider's actual message
    (which is exactly what you need to tell "bad model name" apart from "bad key").
    429 (rate limit) fails FAST instead of retrying: the router's next provider is
    almost always faster than waiting out a quota here, unless the provider tells us
    exactly how long via Retry-After and it's short enough to be worth it."""
    import time as _time

    import requests

    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            resp = requests.post(url, headers=headers, json=json_body, timeout=timeout)
        except requests.exceptions.RequestException as e:
            last_exc = e
            if attempt < max_retries:
                wait = 1.5 * (attempt + 1)
                log.warning(
                    "%s falló (intento %d/%d): %s — reintentando en %.1fs",
                    url, attempt + 1, max_retries + 1, last_exc, wait,
                )
                _time.sleep(wait)
            continue

        if resp.status_code < 400:
            return resp

        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            wait = None
            if retry_after:
                try:
                    wait = float(retry_after)
                except ValueError:
                    pass
            exc = requests.exceptions.HTTPError(f"429 Error: {resp.text[:1000]}", response=resp)
            if wait is not None and wait <= 3 and attempt < max_retries:
                log.warning("%s: rate limited, reintentando en %.1fs (Retry-After)", url, wait)
                _time.sleep(wait)
                last_exc = exc
                continue
            raise exc  # no Retry-After, or it's long — let the router try the next provider

        if resp.status_code in (500, 502, 503, 504):
            last_exc = requests.exceptions.HTTPError(f"{resp.status_code} Error: {resp.text[:1000]}", response=resp)
            if attempt < max_retries:
                wait = 1.5 * (attempt + 1)
                log.warning(
                    "%s falló (intento %d/%d): %s — reintentando en %.1fs",
                    url, attempt + 1, max_retries + 1, last_exc, wait,
                )
                _time.sleep(wait)
            continue

        # Any other 4xx: not transient, raise immediately WITH the body.
        raise requests.exceptions.HTTPError(f"{resp.status_code} Client Error: {resp.text[:1000]}", response=resp)
    raise last_exc  # type: ignore[misc]


def _openai_chat_step(
    cfg: ProviderConfig, messages: list[dict], tools: list[dict], *, max_tokens: int, temperature: float
) -> dict:
    api_key = _api_key(cfg)
    body: dict = {
        "model": _model(cfg),
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if tools:
        body["tools"] = tools
        body["tool_choice"] = "auto"
    if cfg.name == "nvidia":
        enable_thinking = os.environ.get("NEMOTRON_ENABLE_THINKING", "false").strip().lower() in (
            "1", "true", "yes",
        )
        body["chat_template_kwargs"] = {"enable_thinking": enable_thinking}

    resp = _post_with_retry(
        f"{cfg.base_url.rstrip('/')}/chat/completions",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json_body=body,
        timeout=_timeout(cfg),
    )
    return resp.json()["choices"][0]["message"]


# ---------------------------- Anthropic-wire (Claude) ----------------------------

def _messages_to_anthropic(messages: list[dict]) -> tuple[str, list[dict]]:
    """Split out the system prompt and convert the rest to Anthropic's block format."""
    system = ""
    out: list[dict] = []
    for m in messages:
        role = m.get("role")
        if role == "system":
            system = (system + "\n" + (m.get("content") or "")).strip()
        elif role == "user":
            out.append({"role": "user", "content": m.get("content") or ""})
        elif role == "assistant":
            blocks = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for tc in m.get("tool_calls") or []:
                try:
                    args = json.loads(tc["function"].get("arguments") or "{}")
                except (ValueError, TypeError):
                    args = {}
                blocks.append(
                    {
                        "type": "tool_use",
                        "id": tc.get("id", tc["function"]["name"]),
                        "name": tc["function"]["name"],
                        "input": args,
                    }
                )
            out.append({"role": "assistant", "content": blocks or ""})
        elif role == "tool":
            out.append(
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": m.get("tool_call_id", ""),
                            "content": m.get("content") or "",
                        }
                    ],
                }
            )
    return system, out


def _tools_to_anthropic(tools: list[dict]) -> list[dict]:
    return [
        {
            "name": t["function"]["name"],
            "description": t["function"].get("description", ""),
            "input_schema": t["function"].get("parameters") or {"type": "object", "properties": {}},
        }
        for t in tools
    ]


def _anthropic_chat_step(
    cfg: ProviderConfig, messages: list[dict], tools: list[dict], *, max_tokens: int, temperature: float
) -> dict:
    api_key = _api_key(cfg)
    system, conv = _messages_to_anthropic(messages)
    body: dict = {
        "model": _model(cfg),
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": conv,
    }
    if system:
        body["system"] = system
    if tools:
        body["tools"] = _tools_to_anthropic(tools)

    resp = _post_with_retry(
        f"{cfg.base_url.rstrip('/')}/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        json_body=body,
        timeout=_timeout(cfg),
    )
    data = resp.json()

    text_parts = []
    tool_calls = []
    for block in data.get("content", []):
        if block.get("type") == "text":
            text_parts.append(block.get("text", ""))
        elif block.get("type") == "tool_use":
            tool_calls.append(
                {
                    "id": block.get("id", block.get("name")),
                    "type": "function",
                    "function": {
                        "name": block.get("name"),
                        "arguments": json.dumps(block.get("input") or {}, ensure_ascii=False),
                    },
                }
            )
    return {
        "role": "assistant",
        "content": "\n".join(text_parts).strip() or None,
        "tool_calls": tool_calls or None,
    }


# --------------------------------- Entry point ---------------------------------

def chat_step(
    messages: list[dict],
    tools: list[dict],
    *,
    provider: str | None = None,
    max_tokens: int = 1500,
    temperature: float = 0.3,
) -> dict:
    """One LLM call to ONE SPECIFIC provider (never "auto" — use
    chat_step_with_fallback for routing/fallback). Always returns an OpenAI-shaped
    message dict: {"role": "assistant", "content": str | None, "tool_calls": list | None}."""
    cfg = resolve_provider(provider)
    if cfg.wire == "anthropic":
        return _anthropic_chat_step(cfg, messages, tools, max_tokens=max_tokens, temperature=temperature)
    return _openai_chat_step(cfg, messages, tools, max_tokens=max_tokens, temperature=temperature)


def chat_step_with_fallback(
    messages: list[dict],
    tools: list[dict],
    *,
    complexity: str = "simple",
    max_tokens: int = 1500,
    temperature: float = 0.3,
    max_attempts: int | None = None,
    exclude: set[str] | None = None,
) -> tuple[dict, str]:
    """Routed call: picks a provider for this task's complexity (or honors a pinned
    JARVIS_LLM_PROVIDER), and if the call itself fails (bad/placeholder key, rate
    limit, outage), retries with the next-best candidate instead of giving up.
    `exclude` permanently rules out specific providers for THIS call only (e.g. Gemini
    on a continuation step — see nemotron_mcp_agent.py) without touching their health
    cooldown, since it's not that they're down, just structurally wrong for this call.
    Returns (message, provider_name_that_answered)."""
    pinned = (os.environ.get("JARVIS_LLM_PROVIDER") or "auto").strip().lower()
    if pinned and pinned != "auto":
        if pinned not in PROVIDERS:
            raise RuntimeError(f"JARVIS_LLM_PROVIDER={pinned!r} desconocido.")
        return chat_step(messages, tools, provider=pinned, max_tokens=max_tokens, temperature=temperature), pinned

    # Default: try every provider configured for this rank list, not an arbitrary
    # fixed count — otherwise a short list length silently cuts off candidates
    # (e.g. FAST_RANK has 4 entries; capping at 3 would never reach the last one).
    if max_attempts is None:
        max_attempts = len(FAST_RANK if complexity != "complex" else QUALITY_RANK)

    tried: set[str] = set(exclude or ())
    last_exc: Exception | None = None
    for _ in range(max_attempts):
        candidate = pick_provider(complexity, exclude=tried)
        if candidate is None:
            break
        tried.add(candidate)
        try:
            return (
                chat_step(messages, tools, provider=candidate, max_tokens=max_tokens, temperature=temperature),
                candidate,
            )
        except Exception as e:
            last_exc = e
            llm_health.mark_unhealthy_from_exception(candidate, e)
            log.warning("Proveedor %s falló, probando el siguiente: %s", candidate, e)
    if last_exc:
        raise last_exc
    raise RuntimeError(
        "Ningún proveedor de IA tiene una API key configurada. "
        "Cargá al menos una en el .env (NVIDIA_API_KEY, GEMINI_API_KEY, etc.)."
    )