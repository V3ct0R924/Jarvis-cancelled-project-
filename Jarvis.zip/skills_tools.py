#!/usr/bin/env python3
"""
skills.py — a folder of SKILL.md files (skills/<name>/SKILL.md) the agent can check
before doing a task it's likely to get wrong by guessing: which library to use for a
PowerPoint/Excel/Word/PDF, common pitfalls, a working code pattern to start from.

Same idea as Claude Code's own skills system: read the relevant SKILL.md BEFORE
writing any code or creating any file of that type, instead of improvising and
producing something fragile.

Add more skills by dropping a new skills/<name>/SKILL.md with the same frontmatter
shape (name, description) — no code changes needed, list_skills()/ReadSkill pick it up
automatically.
"""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger("skills")

SKILLS_DIR = Path(__file__).resolve().parent / "skills"


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Very small YAML-ish frontmatter parser: '---\\nkey: value\\n---\\nbody'."""
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    meta: dict[str, str] = {}
    for line in parts[1].strip().splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip()
    return meta, parts[2].lstrip("\n")


def list_skills() -> list[dict]:
    out = []
    if not SKILLS_DIR.is_dir():
        return out
    for entry in sorted(SKILLS_DIR.iterdir()):
        skill_file = entry / "SKILL.md"
        if skill_file.is_file():
            meta, _ = _parse_frontmatter(skill_file.read_text(encoding="utf-8"))
            out.append(
                {
                    "name": meta.get("name", entry.name),
                    "description": meta.get("description", ""),
                }
            )
    return out


def read_skill(name: str) -> str:
    skill_file = SKILLS_DIR / name / "SKILL.md"
    if not skill_file.is_file():
        available = ", ".join(s["name"] for s in list_skills()) or "(ninguna)"
        return f"No existe la skill '{name}'. Disponibles: {available}"
    _, body = _parse_frontmatter(skill_file.read_text(encoding="utf-8"))
    return body.strip()


def list_skills_tool() -> str:
    skills = list_skills()
    if not skills:
        return "No hay skills cargadas en la carpeta skills/."
    return "\n".join(f"- {s['name']}: {s['description']}" for s in skills)


TOOLS: dict[str, dict] = {
    "ListSkills": {
        "schema": {
            "type": "function",
            "function": {
                "name": "ListSkills",
                "description": (
                    "List the available skills (name + one-line description). Call "
                    "this if you're not sure whether a skill exists for the task "
                    "(e.g. generating a specific document type)."
                ),
                "parameters": {"type": "object", "properties": {}},
            },
        },
        "func": list_skills_tool,
    },
    "ReadSkill": {
        "schema": {
            "type": "function",
            "function": {
                "name": "ReadSkill",
                "description": (
                    "Read the full instructions for a skill by name (e.g. 'pptx', "
                    "'xlsx', 'docx', 'pdf'). ALWAYS call this before writing any code "
                    "or creating a file of a type that has a matching skill — it has "
                    "the exact library, a working code pattern, and pitfalls to avoid, "
                    "instead of you having to guess."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}},
                    "required": ["name"],
                },
            },
        },
        "func": read_skill,
    },
}


def schemas() -> list[dict]:
    return [entry["schema"] for entry in TOOLS.values()]


def call(name: str, args: dict) -> str:
    entry = TOOLS.get(name)
    if entry is None:
        return f"Tool de skills desconocida: {name}"
    try:
        return entry["func"](**args)
    except TypeError as e:
        return f"Argumentos inválidos para {name}: {e}"
    except Exception as e:
        return f"Error en {name}: {e}"