#!/usr/bin/env python3
"""
printing_tools.py — local tools for a 3D-printing side business: a small SQLite
filament inventory (add spools, use grams off one after a print, see what's running
low) and a live printer-status check over the network.

Unlike the 3d-print SKILL.md (which is instructions the model follows), these need
actual persisted state and a real HTTP call, so they're proper local tools instead —
same pattern as vscode_tools.py/skills_tools.py, merged into the same tool-calling loop.

Printer status supports EITHER OctoPrint OR Moonraker (Klipper — Creality K1, Voron,
etc.), whichever you configure. Set exactly one pair in .env:

  OCTOPRINT_URL=http://192.168.0.50
  OCTOPRINT_API_KEY=...

  # or, for Klipper/Moonraker printers instead:
  MOONRAKER_URL=http://192.168.0.51

Filament inventory lives in its own SQLite file (default: filament_inventory.sqlite3,
next to this script; override with FILAMENT_DB env var) — separate from
jarvis_memory.sqlite3, different data, no reason to mix them.
"""

from __future__ import annotations

import logging
import os
import sqlite3
import time
from pathlib import Path

log = logging.getLogger("printing_tools")

DB_PATH = Path(
    os.environ.get("FILAMENT_DB") or (Path(__file__).resolve().parent / "filament_inventory.sqlite3")
)


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS spools (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            color TEXT NOT NULL,
            material TEXT NOT NULL,
            brand TEXT,
            weight_g REAL NOT NULL,
            remaining_g REAL NOT NULL,
            added_ts REAL NOT NULL
        )
        """
    )
    return conn


def filament_add(color: str, material: str, weight_g: float, brand: str = "") -> str:
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO spools (color, material, brand, weight_g, remaining_g, added_ts) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (color, material, brand, weight_g, weight_g, time.time()),
        )
        spool_id = cur.lastrowid
    return f"Spool agregado (id {spool_id}): {color} {material} {brand or ''} — {weight_g:.0f}g".strip()


def filament_list() -> str:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, color, material, brand, weight_g, remaining_g FROM spools ORDER BY id"
        ).fetchall()
    if not rows:
        return "No hay spools cargados todavía. Usá FilamentAdd para agregar uno."
    lines = []
    for spool_id, color, material, brand, weight_g, remaining_g in rows:
        pct = (remaining_g / weight_g * 100) if weight_g else 0
        lines.append(
            f"#{spool_id} {color} {material} {brand or ''} — {remaining_g:.0f}g / {weight_g:.0f}g ({pct:.0f}%)".replace("  ", " ")
        )
    return "\n".join(lines)


def filament_use(spool_id: int, grams: float) -> str:
    with _connect() as conn:
        row = conn.execute(
            "SELECT color, material, remaining_g FROM spools WHERE id = ?", (spool_id,)
        ).fetchone()
        if not row:
            return f"No existe el spool #{spool_id}. Usá FilamentList para ver los ids."
        color, material, remaining_g = row
        new_remaining = max(0.0, remaining_g - grams)
        conn.execute("UPDATE spools SET remaining_g = ? WHERE id = ?", (new_remaining, spool_id))
    warn = " ⚠️ queda poco" if new_remaining < 100 else ""
    return f"Spool #{spool_id} ({color} {material}): {remaining_g:.0f}g → {new_remaining:.0f}g{warn}"


def filament_low(threshold_g: float = 100) -> str:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, color, material, remaining_g FROM spools WHERE remaining_g < ? ORDER BY remaining_g",
            (threshold_g,),
        ).fetchall()
    if not rows:
        return f"Ningún spool por debajo de {threshold_g:.0f}g."
    return "\n".join(f"#{i} {c} {m}: {r:.0f}g restantes" for i, c, m, r in rows)


def _octoprint_status() -> dict | None:
    url = (os.environ.get("OCTOPRINT_URL") or "").strip().rstrip("/")
    key = (os.environ.get("OCTOPRINT_API_KEY") or "").strip()
    if not url or not key:
        return None
    import requests

    resp = requests.get(f"{url}/api/job", headers={"X-Api-Key": key}, timeout=8)
    resp.raise_for_status()
    data = resp.json()
    state = data.get("state", "?")
    progress = (data.get("progress") or {}).get("completion")
    time_left = (data.get("progress") or {}).get("printTimeLeft")
    return {"state": state, "progress": progress, "time_left_s": time_left}


def _moonraker_status() -> dict | None:
    url = (os.environ.get("MOONRAKER_URL") or "").strip().rstrip("/")
    if not url:
        return None
    import requests

    resp = requests.get(
        f"{url}/printer/objects/query?print_stats=state,filename,print_duration&virtual_sdcard=progress",
        timeout=8,
    )
    resp.raise_for_status()
    result = resp.json().get("result", {}).get("status", {})
    print_stats = result.get("print_stats", {})
    progress = (result.get("virtual_sdcard", {}) or {}).get("progress")
    return {
        "state": print_stats.get("state", "?"),
        "filename": print_stats.get("filename"),
        "progress": (progress * 100) if progress is not None else None,
    }


def printer_status() -> str:
    try:
        data = _octoprint_status()
        source = "OctoPrint"
        if data is None:
            data = _moonraker_status()
            source = "Moonraker"
    except Exception as e:
        return f"No se pudo consultar la impresora: {e}"

    if data is None:
        return (
            "No hay una impresora configurada. Cargá OCTOPRINT_URL + OCTOPRINT_API_KEY "
            "(OctoPrint) o MOONRAKER_URL (Klipper/Moonraker) en el .env."
        )

    state = data.get("state", "?")
    progress = data.get("progress")
    parts = [f"[{source}] Estado: {state}"]
    if progress is not None:
        parts.append(f"Progreso: {progress:.1f}%")
    if data.get("time_left_s") is not None:
        mins = int(data["time_left_s"] // 60)
        parts.append(f"Tiempo restante: ~{mins} min")
    if data.get("filename"):
        parts.append(f"Archivo: {data['filename']}")
    return " — ".join(parts)


TOOLS: dict[str, dict] = {
    "FilamentAdd": {
        "schema": {
            "type": "function",
            "function": {
                "name": "FilamentAdd",
                "description": "Register a new filament spool in inventory.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "color": {"type": "string"},
                        "material": {"type": "string", "description": "e.g. PLA, PETG, ABS, TPU"},
                        "weight_g": {"type": "number", "description": "Total spool weight in grams, usually 1000."},
                        "brand": {"type": "string"},
                    },
                    "required": ["color", "material", "weight_g"],
                },
            },
        },
        "func": filament_add,
    },
    "FilamentList": {
        "schema": {
            "type": "function",
            "function": {
                "name": "FilamentList",
                "description": "List all filament spools in inventory with remaining weight.",
                "parameters": {"type": "object", "properties": {}},
            },
        },
        "func": filament_list,
    },
    "FilamentUse": {
        "schema": {
            "type": "function",
            "function": {
                "name": "FilamentUse",
                "description": "Deduct grams from a spool after a print (call FilamentList first to get the spool id).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "spool_id": {"type": "integer"},
                        "grams": {"type": "number"},
                    },
                    "required": ["spool_id", "grams"],
                },
            },
        },
        "func": filament_use,
    },
    "FilamentLow": {
        "schema": {
            "type": "function",
            "function": {
                "name": "FilamentLow",
                "description": "List spools below a weight threshold (default 100g) — for restock alerts.",
                "parameters": {
                    "type": "object",
                    "properties": {"threshold_g": {"type": "number"}},
                },
            },
        },
        "func": filament_low,
    },
    "PrinterStatus": {
        "schema": {
            "type": "function",
            "function": {
                "name": "PrinterStatus",
                "description": "Check the current job status of the networked 3D printer (OctoPrint or Moonraker/Klipper, whichever is configured): printing or idle, % progress, time left.",
                "parameters": {"type": "object", "properties": {}},
            },
        },
        "func": printer_status,
    },
}


def schemas() -> list[dict]:
    return [entry["schema"] for entry in TOOLS.values()]


def call(name: str, args: dict) -> str:
    entry = TOOLS.get(name)
    if entry is None:
        return f"Tool de impresión 3D desconocida: {name}"
    try:
        return entry["func"](**args)
    except TypeError as e:
        return f"Argumentos inválidos para {name}: {e}"
    except Exception as e:
        return f"Error en {name}: {e}"