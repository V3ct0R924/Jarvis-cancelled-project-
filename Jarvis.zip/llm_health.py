#!/usr/bin/env python3
"""
llm_health.py — a cheap (1-token) ping to every configured provider at startup, plus a
live circuit breaker: whenever a provider fails a real call (rate limit, outage, bad
key), it gets marked unavailable for a cooldown window so the router stops trying it
every single turn — no more "probando groq -> falló, probando gemini -> falló,
probando mistral -> falló, funciona nvidia" on every request once we already know
which ones are down.

Called from two places:
  - jarvis.py, once at startup: run_startup_check() pings everything configured.
  - llm_providers.py, on every real call: mark_unhealthy()/is_healthy() gate who the
    router is even allowed to pick, and mark_unhealthy_from_exception() reads
    Retry-After off a failed response when the provider gives one.

Pure bookkeeping only — no import of llm_providers at module load time, so
llm_providers can import THIS module without a circular import. run_startup_check()
imports llm_providers lazily, inside the function, once both modules already exist.

Env:
  JARVIS_HEALTH_COOLDOWN_S   default cooldown in seconds when a provider fails with no
                             Retry-After hint of its own (default: 120)
  JARVIS_HEALTH_CHECK_ON_START   true (default) | false — skip the startup ping
                                 entirely (e.g. if you want zero extra startup latency
                                 and are fine with the live circuit breaker alone)
"""

from __future__ import annotations

import logging
import os
import threading
import time

log = logging.getLogger("llm_health")

DEFAULT_COOLDOWN_S = float(os.environ.get("JARVIS_HEALTH_COOLDOWN_S", "120"))
# Some failures aren't a "wait N seconds and it's fine" rate limit — they're a
# structural incompatibility (wrong model id, a provider's tool-calling shim rejecting
# something about our request) that will fail the exact same way again in 2 minutes.
# Give those a much longer cooldown instead of retrying them every couple of turns.
LONG_COOLDOWN_S = float(os.environ.get("JARVIS_HEALTH_LONG_COOLDOWN_S", "3600"))
_STRUCTURAL_ERROR_HINTS = (
    "thought_signature", "model_not_found", "does not exist", "is not found",
    "invalid_api_key", "unauthorized", "invalid x-api-key", "incorrect api key",
)

_lock = threading.Lock()
_unhealthy_until: dict[str, float] = {}


def mark_unhealthy(name: str, seconds: float | None = None) -> None:
    cooldown = seconds if seconds is not None else DEFAULT_COOLDOWN_S
    cooldown = max(cooldown, 1.0)
    with _lock:
        _unhealthy_until[name] = time.time() + cooldown
    log.warning("%s: no disponible por %.0fs", name, cooldown)


def mark_healthy(name: str) -> None:
    with _lock:
        _unhealthy_until.pop(name, None)


def is_healthy(name: str) -> bool:
    with _lock:
        until = _unhealthy_until.get(name)
    return until is None or time.time() >= until


def status() -> dict[str, float]:
    """Seconds remaining in cooldown for each currently-unhealthy provider."""
    now = time.time()
    with _lock:
        return {n: round(u - now, 1) for n, u in _unhealthy_until.items() if u > now}


def _retry_after_seconds(exc: Exception) -> float | None:
    resp = getattr(exc, "response", None)
    headers = getattr(resp, "headers", None)
    if not headers:
        return None
    val = headers.get("Retry-After")
    if not val:
        return None
    try:
        return float(val)
    except ValueError:
        return None


def mark_unhealthy_from_exception(name: str, exc: Exception) -> None:
    retry_after = _retry_after_seconds(exc)
    if retry_after is not None:
        mark_unhealthy(name, retry_after)
        return
    low = str(exc).lower()
    if any(hint in low for hint in _STRUCTURAL_ERROR_HINTS):
        log.warning(
            "%s: falla estructural (no un rate limit transitorio) — cooldown largo de %.0fs",
            name, LONG_COOLDOWN_S,
        )
        mark_unhealthy(name, LONG_COOLDOWN_S)
        return
    mark_unhealthy(name, DEFAULT_COOLDOWN_S)


def run_startup_check(providers: list[str] | None = None, *, parallel: bool = True) -> dict[str, bool]:
    """One max_tokens=1 call per configured provider ('hi' in, one token out — the
    cheapest possible real request). Marks failures unhealthy immediately so the very
    first real task doesn't have to discover it the slow way."""
    if os.environ.get("JARVIS_HEALTH_CHECK_ON_START", "true").strip().lower() not in ("1", "true", "yes"):
        log.info("Chequeo de salud al arranque desactivado (JARVIS_HEALTH_CHECK_ON_START=false).")
        return {}

    import llm_providers  # lazy import — see module docstring

    # Only check providers actually eligible for routing (QUALITY_RANK/FAST_RANK) —
    # checking a configured-but-unranked provider would just waste the startup time
    # it was supposed to save, since pick_provider() would never select it anyway.
    ranked = set(llm_providers.QUALITY_RANK) | set(llm_providers.FAST_RANK)
    names = providers or [
        n for n in llm_providers.PROVIDERS if n in ranked and llm_providers.has_real_key(n)
    ]
    if not names:
        log.warning("Ningún proveedor tiene una API key configurada — nada que chequear.")
        return {}

    results: dict[str, bool] = {}

    def _check_one(name: str) -> None:
        start = time.time()
        try:
            llm_providers.chat_step(
                [{"role": "user", "content": "hi"}], [], provider=name, max_tokens=1, temperature=0
            )
            mark_healthy(name)
            results[name] = True
            log.info("Chequeo %s: OK (%.1fs)", name, time.time() - start)
        except Exception as e:
            mark_unhealthy_from_exception(name, e)
            results[name] = False
            log.warning("Chequeo %s: falló (%.1fs): %s", name, time.time() - start, e)

    if parallel and len(names) > 1:
        threads = [threading.Thread(target=_check_one, args=(n,), daemon=True) for n in names]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
    else:
        for n in names:
            _check_one(n)

    ok = [n for n, healthy in results.items() if healthy]
    down = [n for n, healthy in results.items() if not healthy]
    log.info("Chequeo de salud: OK=%s, no disponible=%s", ok or "-", down or "-")
    return results


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    run_startup_check()