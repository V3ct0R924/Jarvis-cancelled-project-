---
name: docx
description: Crear documentos de Word (.docx) con python-docx, corriendo un script vía FileSystem + PowerShell.
---

# Crear un .docx

No uses la UI de Word para tipear. Generá el archivo con código.

1. Si no está instalado: `PowerShell` con `python -m pip install python-docx --quiet --disable-pip-version-check`.
2. Escribí el script Python con `FileSystem` a una ruta temporal.
3. Corré el script con `PowerShell`: `python C:\...\jarvis_docx_build.py`.
4. El resultado queda en la ruta pedida (o en el Escritorio si no se especificó).

> **Instalación: una sola vez, sin repetir a ciegas.** Usá siempre `python -m pip install ...` (no `pip install` a secas — a veces `pip` no está en el PATH aunque `python -m pip` sí funciona). Si el primer intento de instalación falla, revisá el mensaje de error antes de reintentar con otra variante — no relances el mismo comando ni cambies de estrategia a ciegas varias veces seguidas, eso es lo que hace que esto tarde minutos en vez de segundos. Para encadenar comandos en PowerShell usá `;`, no `&&` (`&&` solo anda en PowerShell 7+, no en Windows PowerShell 5.1, que es el default en muchas instalaciones de Windows).

## Patrón de código mínimo

```python
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

titulo = doc.add_heading("Título del documento", level=0)

doc.add_heading("Introducción", level=1)
doc.add_paragraph(
    "Texto normal del párrafo. Se puede mezclar "
).add_run("texto en negrita").bold = True

doc.add_heading("Lista de puntos", level=1)
for item in ["Primer punto", "Segundo punto", "Tercer punto"]:
    doc.add_paragraph(item, style="List Bullet")

tabla = doc.add_table(rows=1, cols=3)
tabla.style = "Light Grid Accent 1"
hdr = tabla.rows[0].cells
hdr[0].text, hdr[1].text, hdr[2].text = "Columna A", "Columna B", "Columna C"
for fila in [("1", "2", "3"), ("4", "5", "6")]:
    row_cells = tabla.add_row().cells
    for cell, valor in zip(row_cells, fila):
        cell.text = valor

doc.save(r"C:\Users\loles\Desktop\documento.docx")
print("OK")
```

## Reglas prácticas

- `add_heading(texto, level=0)` es el título del documento; `level=1,2,3` son
  subtítulos jerárquicos (para que se vean bien en el índice si el usuario pide uno).
- Para negrita/cursiva dentro de un párrafo, hay que operar sobre "runs":
  `p = doc.add_paragraph(); run = p.add_run("texto"); run.bold = True`.
- Estilos de lista disponibles: `"List Bullet"`, `"List Number"`.
- Si el pedido es "editá este Word" (no crear uno nuevo), abrí con
  `Document(ruta_existente)` en vez de crear un `Document()` vacío — así se
  conserva el contenido previo.
- Después de guardar, avisá la ruta final en la respuesta.