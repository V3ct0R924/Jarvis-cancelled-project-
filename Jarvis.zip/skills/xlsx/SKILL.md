---
name: xlsx
description: Crear/editar planillas de Excel (.xlsx) con openpyxl (o pandas para datos tabulares grandes), corriendo un script vía FileSystem + PowerShell.
---

# Crear/editar un .xlsx

No uses la UI de Excel para tipear celda por celda. Generá el archivo con código.

1. Si no está instalado: `PowerShell` con `python -m pip install openpyxl pandas --quiet --disable-pip-version-check`.
2. Escribí el script Python con `FileSystem` a una ruta temporal.
3. Corré el script con `PowerShell`: `python C:\...\jarvis_xlsx_build.py`.
4. El resultado queda en la ruta pedida (o en el Escritorio si no se especificó).

> **Instalación: una sola vez, sin repetir a ciegas.** Usá siempre `python -m pip install ...` (no `pip install` a secas — a veces `pip` no está en el PATH aunque `python -m pip` sí funciona). Si el primer intento de instalación falla, revisá el mensaje de error antes de reintentar con otra variante — no relances el mismo comando ni cambies de estrategia a ciegas varias veces seguidas, eso es lo que hace que esto tarde minutos en vez de segundos. Para encadenar comandos en PowerShell usá `;`, no `&&` (`&&` solo anda en PowerShell 7+, no en Windows PowerShell 5.1, que es el default en muchas instalaciones de Windows).

## Caso simple: pocas filas, con fórmulas o formato — usar openpyxl

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

wb = Workbook()
ws = wb.active
ws.title = "Datos"

headers = ["Producto", "Cantidad", "Precio", "Total"]
ws.append(headers)
for cell in ws[1]:
    cell.font = Font(bold=True)
    cell.fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")

filas = [
    ("Mouse", 3, 12.50),
    ("Teclado", 2, 45.00),
]
for fila_num, (producto, cantidad, precio) in enumerate(filas, start=2):
    ws.cell(row=fila_num, column=1, value=producto)
    ws.cell(row=fila_num, column=2, value=cantidad)
    ws.cell(row=fila_num, column=3, value=precio)
    ws.cell(row=fila_num, column=4, value=f"=B{fila_num}*C{fila_num}")

for col, width in zip("ABCD", [18, 12, 12, 12]):
    ws.column_dimensions[col].width = width

wb.save(r"C:\Users\loles\Desktop\planilla.xlsx")
print("OK")
```

## Caso de datos tabulares grandes (CSV, exportar un dataset) — usar pandas

```python
import pandas as pd

df = pd.DataFrame({
    "Producto": ["Mouse", "Teclado"],
    "Cantidad": [3, 2],
    "Precio": [12.50, 45.00],
})
df["Total"] = df["Cantidad"] * df["Precio"]
df.to_excel(r"C:\Users\loles\Desktop\planilla.xlsx", index=False, sheet_name="Datos")
print("OK")
```

## Reglas prácticas

- Fórmulas de Excel van como string empezando con `=` (`f"=B{fila}*C{fila}"`), openpyxl
  las guarda tal cual, Excel las calcula al abrir.
- Si el usuario pidió gráficos, openpyxl soporta `from openpyxl.chart import BarChart,
  Reference` — armar el chart y `ws.add_chart(chart, "F2")`.
- Si el pedido es "leé este Excel y..." (no crear uno nuevo), usá `openpyxl.load_workbook(ruta)`
  o `pd.read_excel(ruta)` en vez de re-crear todo de cero.
- Después de guardar, avisá la ruta final en la respuesta — no asumas que el usuario
  sabe dónde quedó si no lo pidió explícitamente.