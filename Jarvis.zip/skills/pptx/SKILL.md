---
name: pptx
description: Crear presentaciones de PowerPoint (.pptx) con python-pptx, corriendo un script vía FileSystem + PowerShell.
---

# Crear un .pptx

No uses la UI de PowerPoint (abrir la app y clickear/tipear) — es lento y frágil.
En vez de eso, generá el archivo con código:

1. Si no está instalado: `PowerShell` con `python -m pip install python-pptx --quiet --disable-pip-version-check`.
2. Escribí un script Python con `FileSystem` (mode=write) a una ruta temporal,
   por ejemplo `C:\Users\<user>\AppData\Local\Temp\jarvis_pptx_build.py`.
3. Corré ese script con `PowerShell`: `python C:\...\jarvis_pptx_build.py`.
4. El script deja el `.pptx` final en la ruta que el usuario pidió (o en el
   Escritorio si no especificó dónde).

> **Instalación: una sola vez, sin repetir a ciegas.** Usá siempre `python -m pip install ...` (no `pip install` a secas — a veces `pip` no está en el PATH aunque `python -m pip` sí funciona). Si el primer intento de instalación falla, revisá el mensaje de error antes de reintentar con otra variante — no relances el mismo comando ni cambies de estrategia a ciegas varias veces seguidas, eso es lo que hace que esto tarde minutos en vez de segundos. Para encadenar comandos en PowerShell usá `;`, no `&&` (`&&` solo anda en PowerShell 7+, no en Windows PowerShell 5.1, que es el default en muchas instalaciones de Windows).

## Patrón de código mínimo

```python
from pptx import Presentation
from pptx.util import Inches, Pt

prs = Presentation()

# Slide de título
slide = prs.slides.add_slide(prs.slide_layouts[0])
slide.shapes.title.text = "Título de la presentación"
slide.placeholders[1].text = "Subtítulo o autor"

# Slide de contenido con bullets
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Título del slide"
body = slide.placeholders[1].text_frame
body.text = "Primer punto"
for punto in ["Segundo punto", "Tercer punto"]:
    p = body.add_paragraph()
    p.text = punto
    p.level = 0

prs.save(r"C:\Users\loles\Desktop\presentacion.pptx")
print("OK")
```

## Reglas prácticas

- Layout 0 = portada (título + subtítulo). Layout 1 = título + contenido (bullets).
  Layout 6 = en blanco, para armar cajas de texto/imágenes a mano con
  `slide.shapes.add_textbox(...)`.
- Para imágenes: `slide.shapes.add_picture(ruta, Inches(x), Inches(y), width=Inches(w))`.
- Para tablas: `slide.shapes.add_table(filas, columnas, left, top, width, height).table`,
  después `table.cell(fila, col).text = "..."`.
- No metas más de ~6 bullets por slide ni párrafos largos — si el usuario pidió
  mucho contenido, repartilo en más slides en vez de saturar uno solo.
- Al final, abrí el archivo generado con `VSCodeOpen` si el usuario está en modo
  código, o simplemente con `App`/`PowerShell Start-Process` para que lo vea en
  PowerPoint directamente.