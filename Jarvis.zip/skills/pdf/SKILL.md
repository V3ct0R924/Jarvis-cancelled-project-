---
name: pdf
description: Crear PDFs desde cero con reportlab, o combinar/convertir usando pypdf, corriendo un script vía FileSystem + PowerShell.
---

# Crear/editar un .pdf

1. Si no está instalado: `PowerShell` con `python -m pip install reportlab pypdf --quiet --disable-pip-version-check`.
2. Escribí el script Python con `FileSystem` a una ruta temporal.
3. Corré el script con `PowerShell`: `python C:\...\jarvis_pdf_build.py`.
4. El resultado queda en la ruta pedida (o en el Escritorio si no se especificó).

> **Instalación: una sola vez, sin repetir a ciegas.** Usá siempre `python -m pip install ...` (no `pip install` a secas — a veces `pip` no está en el PATH aunque `python -m pip` sí funciona). Si el primer intento de instalación falla, revisá el mensaje de error antes de reintentar con otra variante — no relances el mismo comando ni cambies de estrategia a ciegas varias veces seguidas, eso es lo que hace que esto tarde minutos en vez de segundos. Para encadenar comandos en PowerShell usá `;`, no `&&` (`&&` solo anda en PowerShell 7+, no en Windows PowerShell 5.1, que es el default en muchas instalaciones de Windows).

## PDF desde cero — reportlab

```python
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas

c = canvas.Canvas(r"C:\Users\loles\Desktop\documento.pdf", pagesize=A4)
ancho, alto = A4

c.setFont("Helvetica-Bold", 20)
c.drawString(2 * cm, alto - 3 * cm, "Título del documento")

c.setFont("Helvetica", 12)
texto = c.beginText(2 * cm, alto - 5 * cm)
for linea in ["Primera línea de texto.", "Segunda línea de texto."]:
    texto.textLine(linea)
c.drawText(texto)

c.showPage()
c.save()
print("OK")
```

## Combinar o extraer páginas de PDFs existentes — pypdf

```python
from pypdf import PdfReader, PdfWriter

writer = PdfWriter()
for ruta in [r"C:\a.pdf", r"C:\b.pdf"]:
    reader = PdfReader(ruta)
    for page in reader.pages:
        writer.add_page(page)

with open(r"C:\Users\loles\Desktop\combinado.pdf", "wb") as f:
    writer.write(f)
print("OK")
```

## Convertir un .docx/.pptx/.xlsx ya generado a PDF

Si Office está instalado, lo más confiable es abrir el archivo y usar
`PowerShell` con COM (`New-Object -ComObject Word.Application`, `.SaveAs2` con
`FileFormat=17`) — más fiable que intentar recrear el layout exacto en reportlab.
Si el usuario no tiene Office, generá el PDF directo con reportlab en vez de
depender de una conversión.

## Reglas prácticas

- reportlab dibuja en coordenadas absolutas (como un lienzo) — no tiene concepto de
  "párrafo que ajusta solo", hay que controlar el salto de línea a mano o usar
  `reportlab.platypus` (`SimpleDocTemplate`, `Paragraph`, `Spacer`) si el contenido
  es largo y necesita fluir entre páginas.
- Para texto largo con formato (títulos, párrafos, tablas) preferí `platypus` en vez
  de `canvas` a mano — mucho menos propenso a que el texto se corte o se superponga.