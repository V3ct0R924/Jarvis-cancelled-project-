---
name: 3d-print
description: Detectar qué laminador está instalado (PrusaSlicer/OrcaSlicer/SuperSlicer/Bambu Studio/Cura) y usarlo para pasar un STL a G-code, leer tiempo/peso estimado, y armar una cotización. Usa las tools FilamentAdd/FilamentList/FilamentUse/PrinterStatus para inventario y estado de la impresora.
---

# Laminar un STL y cotizar una impresión 3D

## 0. Detectar qué laminador está instalado — NUNCA asumas cuál es

No sabemos de antemano qué programa tiene instalado el usuario. Antes de laminar,
revisá cuáles de estos existen (con `FileSystem` para las rutas, o `PowerShell` con
`Get-Command <nombre> -ErrorAction SilentlyContinue` para ver si están en el PATH):

| Programa | Ejecutable CLI | Ruta típica en Windows |
|---|---|---|
| PrusaSlicer | `prusa-slicer-console.exe` | `C:\Program Files\Prusa3D\PrusaSlicer\` |
| OrcaSlicer | `orca-slicer-console.exe` (o `orcaslicer_console.exe` según versión) | `C:\Program Files\OrcaSlicer\` |
| SuperSlicer | `superslicer-console.exe` | `C:\Program Files\SuperSlicer\` |
| Bambu Studio | `bambu-studio.exe --slice` | `C:\Program Files\Bambu Studio\` |
| Cura | `CuraEngine.exe` | `C:\Program Files\Ultimaker Cura <version>\` |

PrusaSlicer, OrcaSlicer y SuperSlicer son todos forks del mismo motor — comparten
prácticamente la misma sintaxis de CLI (ver 1a). Bambu Studio también viene de esa
familia pero conviene confirmar los flags con `--help` antes de asumir. Cura es el
raro del grupo: usa `CuraEngine` directo con un `printer_def.json`, sintaxis distinta.

Si encontrás más de uno instalado, preguntale al usuario cuál usa (o fijate cuál
tiene perfiles/configuración ya armada en su `%APPDATA%`, señal de que es el que usa
de verdad). Si no encontrás ninguno, avisá — no sigas de largo intentando adivinar.

## 1. Laminar (STL → G-code)

Preferí la línea de comandos del laminador que detectaste en el paso 0 (rápido, sin
abrir la UI). Si el pedido implica ajustar soportes/orientación a mano, o el usuario
pide explícitamente "abrí el programa", abrí la app de escritorio en su lugar (1b).

### 1a. Por línea de comandos

**PrusaSlicer / OrcaSlicer / SuperSlicer** (misma sintaxis, familia PrusaSlicer):
```powershell
& "<ruta al ejecutable console>" `
  --export-gcode `
  --load "C:\ruta\a\perfil.ini" `
  "C:\ruta\al\modelo.stl" `
  --output "C:\ruta\salida\modelo.gcode"
```
`--load` apunta a un perfil `.ini` exportado desde el programa (Print/Filament/Printer
settings → "Export config"). Si no hay uno, revisá `%APPDATA%\<Programa>\` antes de
pedirle al usuario que exporte uno.

**Cura**:
```powershell
& "C:\Program Files\Ultimaker Cura <version>\CuraEngine.exe" slice `
  -j "C:\ruta\a\printer_def.json" `
  -l "C:\ruta\al\modelo.stl" `
  -o "C:\ruta\salida\modelo.gcode"
```
El `printer_def.json` sale de la config de la impresora en Cura — más enredado que
los de arriba; si no está a mano, mejor abrir la UI (1b) y laminar desde ahí.

### 1b. Por la app de escritorio (cuando hay que ajustar algo a mano)

```
PowerShell: Start-Process "<ruta al .exe de la app>" -ArgumentList '"C:\ruta\al\modelo.stl"'
```
Abre el programa (el que sea, según lo detectado en el paso 0) con el modelo ya
cargado. No sigas laminando por CLI en este caso — el objetivo era justamente
dejarlo para que lo revise a mano.

## 2. Leer el tiempo y peso estimado del G-code resultante

Toda la familia PrusaSlicer (PrusaSlicer/OrcaSlicer/SuperSlicer/Bambu Studio) escribe
esto como comentarios cerca del final del archivo — extraelo con `FileSystem` o:

```powershell
Select-String -Path "C:\ruta\salida\modelo.gcode" -Pattern "estimated printing time|filament used \[g\]"
```

Vas a ver algo como:
```
; estimated printing time (normal mode) = 3h 24m 12s
; filament used [g] = 45.32
```

Cura anota esto distinto (metadata tipo `;TIME:12345` y `;Filament used: 12.3m` en
lugar de gramos directos) — si el G-code viene de Cura, buscá esos patrones en su
lugar.

## 3. Calcular el costo

```
costo_material = (gramos_usados / 1000) * precio_por_kg_del_filamento
costo_electricidad = horas_impresion * (watts_impresora / 1000) * precio_kwh
costo_total = costo_material + costo_electricidad + margen_o_mano_de_obra
```

Si no tenés estos datos (precio del filamento, consumo de la impresora,
precio de la luz, margen deseado), preguntale al usuario en vez de inventar
números — un presupuesto mal calculado es peor que preguntar.

## 4. Armar el documento de la cotización

Una vez calculado el costo, si el usuario quiere un PDF/Word para mandarle al
cliente, llamá `ReadSkill` con `pdf` o `docx` para generarlo con el patrón
correcto — no reinventes eso acá, es un problema ya resuelto por esas skills.

## 5. Inventario y estado de la impresora

- Antes de laminar/cotizar un trabajo grande, podés llamar `FilamentList` para
  ver qué colores/materiales hay disponibles y cuánto queda de cada uno.
- Una vez que el usuario confirma que va a imprimir (no antes, para no
  descontar de más por cotizaciones que no se concretan), llamá
  `FilamentUse` con los gramos que salieron del paso 2 para descontarlos del
  spool correspondiente.
- `PrinterStatus` te dice si la impresora está imprimiendo ahora, en qué
  porcentaje, y cuánto tiempo falta — útil para responder "¿cómo va la
  impresión?" sin tener que ir a mirar físicamente.